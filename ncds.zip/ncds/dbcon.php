<?php

function connect()

{
$connect = mysql_connect("localhost", "root", "") or

die ("No connection");



//make sure our recently created database is the active one

mysql_select_db ("projects");

}

?>

