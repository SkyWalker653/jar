<?php include('includes/db_config.php'); ?>
<?php

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $institute_type_id = $_POST['package'];

    $sql = "SELECT * FROM `tbl_master_institute` WHERE `id` = {$institute_type_id}";

    if ($result = $conn->query($sql)) {
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data = $row['code'];
            }
        }
        $conn->close();
    }
}

echo $data;