<?php include("includes/header.php"); ?>
<?php
/**
 * Created by PhpStorm.
 * User: PriyaRanjan
 * Date: 25-06-2017
 * Time: 08:06 PM
 */

if(
    isset($_SESSION['user_id']) &&
    isset($_SESSION['nodal_ofcr_name'])  &&
    isset($_SESSION['nodal_ofcr_ph'])  &&
    isset($_SESSION['institute_type_id'])  &&
    isset($_SESSION['institute_type'])    &&
    isset($_SESSION['institute_id'])      &&
    isset($_SESSION['institute_name'])    &&
    isset($_SESSION['institute_code'])
)
{
    header("location: dashboard.php");
}

$message = '';

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $institute_id       = trim($_POST['institute_name']);
    $nodal_ofcr_name       = trim($_POST['nodal_ofcr_name']);
    $nodal_ofcr_ph       = trim($_POST['nodal_ofcr_ph']);
    $user_id            = trim($_POST['user_id']);
    $user_pass          = trim($_POST['user_pass']);

    if(empty($institute_id) || empty($user_pass) || empty($nodal_ofcr_name) || empty($nodal_ofcr_ph))
    {
        $message = '<div class="alert alert-warning" role="alert">Please fill all the fields !</div>';
    }
    else
    {
        $sql = "INSERT INTO `tbl_users` (`nodal_ofcr_name`, `nodal_ofcr_ph`, `user_id`, `password`, `institute_id`) VALUES ('" . $nodal_ofcr_name . "','" . $nodal_ofcr_ph . "','" . $user_id . "', '" . password_hash($user_pass, PASSWORD_DEFAULT) . "', '" . $institute_id . "')";

        if ($conn->query($sql) === TRUE) {
            $message = '<div class="alert alert-success" role="alert">User registered successfully !</div><script type="text/javascript">window.location.href = "index.php";</script>';
        } else {
            $message = '<div class="alert alert-danger" role="alert">ERROR:Please refresh!! U are already registered may be.</div>';
        }
    }
}
?>
<div class="row">
    <div class="col-md-12" style="padding-top: 30px;">

        <?php echo $message; ?>

        <form class="form-horizontal" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="form-group">
                <label class="col-sm-2 control-label">Institute Type</label>
                <div class="col-sm-10">
                    <select class="form-control" name="institute_type" id="institute_type" required>
                        <option value="">Select</option>

                        <?php
                            $sql = "SELECT * FROM `tbl_institute_type` ORDER BY type";
                            if($result = $conn->query($sql))
                            {
                                if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        echo '<option value="' . $row['id'] . '">' . $row['type'] . '</option>';
                                    }
                                } else {
                                    echo "0 results";
                                }
                                $conn->close();
                            }
                        ?>

                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">Institute Name</label>
                <div class="col-sm-10">
                    <select class="form-control" name="institute_name" id="institute" required >
                        <option value="">Select</option>
                    </select>
                </div>
            </div>
			
			<div class="form-group">
                <label class="col-sm-2 control-label">Nodal Officer Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="nodal_ofcr_name" placeholder="Nodal Officer Name" name="nodal_ofcr_name" required />
                </div>
            </div>
			
			<div class="form-group">
                <label class="col-sm-2 control-label">Nodal Officer Phone No</label>
                <div class="col-sm-10">
                    <input type="text" class="input-md2 form-control" id="nodal_ofcr_ph" placeholder="Nodal Officer Phone No" name="nodal_ofcr_ph" pattern="^\d{3}\d{3}\d{4}$" required />
                </div>
            </div>
			
            <div class="form-group">
                <label class="col-sm-2 control-label">User ID</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" placeholder="User ID" name="user_id" id="username"/>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="password" placeholder="Password" name="user_pass" required />
                </div>
            </div>
			
			<div class="form-group">
                <label class="col-sm-2 control-label">Confirm Password</label>
                <div class="col-sm-10">
                    <input type="password" id="confirm_password" class="form-control" placeholder="Confirm Password" name="reuser_pass" required />
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <input type="submit" class="btn btn-primary" name="submit_register" value="Register" />
					 <a href="index.php" class="btn btn-primary">Login</a>
                </div>
            </div>
        </form>

    </div>
</div>

<script>
    $(document).ready(function(){
        $("#institute_type").change(function(){
            var institute_type_id = this.value;
            //alert(institute_type_id);

            $.post("includes/ajax/GetInstituteNameByType.php",
                {
                    institute_type_id: institute_type_id
                },
                function(data,status){
                    $("#institute").html(data);
                });
        });
		var password = document.getElementById("password")
  , confirm_password = document.getElementById("confirm_password");

function validatePassword(){
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
  } else {
    confirm_password.setCustomValidity('');
  }
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;
document.getElementById('username').onkeydown = function (e) {
        e.preventDefault();
    };
    document.getElementById('username').oncut = function (e) {
        e.preventDefault();
    };
    document.getElementById('username').onpaste = function (e) {
        e.preventDefault();
    };
$('#institute').change(function(){
var package = $(this).val();
$.ajax({
   type:'POST',
   data:{package:package},
   url:'get_code.php',
   success:function(data){
       $('#username').val(data);
   } 

});
});
    });
</script>
<?php include("includes/footer.php"); ?>