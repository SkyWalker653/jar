<?php if(session_status() !== PHP_SESSION_ACTIVE) {session_start();} ?>
<?php include('includes/db_config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NCD::College Data Collection</title>

    <script src="assets/js/jquery-2.1.4.min.js"></script>


    <!-- bootstrap for better look example, but not necessary -->
    <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css" type="text/css">

    <!-- Step Form Wizard plugin -->
    <link rel="stylesheet" href="assets/plugins/step-form-wizard/css/step-form-wizard-all.css" type="text/css">
    <script src="assets/plugins/step-form-wizard/js/step-form-wizard.js"></script>

    <!-- nicer scroll in steps -->
    <link rel="stylesheet" href="assets/plugins/mcustom-scrollbar/jquery.mCustomScrollbar.min.css">
    <script src="assets/plugins/mcustom-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>

    <!-- validation library http://parsleyjs.org/ -->
    <link rel="stylesheet" href="assets/plugins/parsley/parsley.css" type="text/css" media="screen, projection">
    <script src="assets/plugins/parsley/parsley.min.js"></script>

    <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="http://www.shieldui.com/shared/components/latest/css/light/all.min.css" />
    <script type="text/javascript" src="http://www.shieldui.com/shared/components/latest/js/shieldui-all.min.js"></script>
    <script type="text/javascript" src="http://www.shieldui.com/shared/components/latest/js/jszip.min.js"></script>


    <script>
        var sfw;
        $(document).ready(function () {
            sfw = $("#wizard_example").stepFormWizard({
                height: 'auto',
                onNext: function(i) {
                    var valid = $("#wizard_example").parsley().validate('block' + i);
                    sfw.refresh();
                    return valid;
                },
                onFinish: function(i) {
                    var valid = $("#wizard_example").parsley().validate();
                    // if use height: 'auto' call refresh metod after validation, because parsley can change content
                    sfw.refresh();
                    return valid;
                }
            });
        })
        $(window).load(function () {
            /* only if you want use mcustom scrollbar */
            $(".sf-step").mCustomScrollbar({
                theme: "dark-3",
                scrollButtons: {
                    enable: true
                }
            });
        });
    </script>

    <script type="text/javascript">
        jQuery(function ($) {
            $("#exportButton").click(function () {
                // parse the HTML table element having an id=exportTable
                var dataSource = shield.DataSource.create({
                    data: "#exportTable",
                    schema: {
                        type: "table",
                        fields: {
                            Field_Name: { type: String },
                            Value: { type: Number },

                        }
                    }
                });

                // when parsing is done, export the data to PDF
                dataSource.read().then(function (data) {
                    var pdf = new shield.exp.PDFDocument({
                        author: "PrepBootstrap",
                        created: new Date()
                    });

                    pdf.addPage("a4", "portrait");

                    pdf.table(
                        10,
                        10,
                        data,
                        [
                            { field: "Field_Name", title: "Field Name", width: 290 },
                            { field: "Value", title: "Value", width: 285 }
                        ],
                        {
                            margins: {
                                top: 10,
                                left: 10,
                                right: 10,
                                bottom: 10
                            }
                        }
                    );

                    pdf.saveAs({
                        fileName: "report"
                    });
                });
            });
        });
    </script>

    <style>
        body{
           background: url('http://www.publicdomainpictures.net/pictures/50000/velka/flower-meadow.jpg') no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
        }
        #errmsg
        {
            color: red;
        }
        pre {margin: 45px 0 60px;}

        ul{
            cursor:pointer;
        }

        legend {
            color:#14b5c8;
        }
        #wizard_example {
            color:#285d30;
        }
        .nav-warning { background: #337ab7; color: #ffffff;  filter: alpha(opacity=50); /* internet explorer */
    -khtml-opacity: 0.9;      /* khtml, old safari */
    -moz-opacity: 0.9;       /* mozilla, netscape */
    opacity: 0.9;           /* fx, safari, opera */}
            .nav-warning a { color: #ffffff; }
        .nav-warning a { color: #ffffff; }
        .nav>li>a:focus, .nav>li>a:hover {
            background-color: #b12300;
        }
		.status-available{color:#2FC332;}
.status-not-available{color:#D60202;}
    </style>
</head>
<body>
<nav class="navbar nav-warning">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <span class="navbar-brand">Higher Education Department, Govt. of Odisha</span>
        </div>

        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <?php
                if(isset($_SESSION['user_id']))
                {
                  echo '<li><a href="logout.php">Logout</a></li>';
                }
                ?>
            </ul>
        </div>
    </div>
</nav>
<div class="container"  style="background-color: #FFF; box-shadow: 0 1px 6px rgba(0, 0, 0, 0.12), 0 1px 4px rgba(0, 0, 0, 0.24); width:60em;
">
    <div class="site-index">
        <div class="body-content">