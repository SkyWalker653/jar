<?php include('../db_config.php'); ?>
<?php

$data = '<option value="">Select</option>';
$institute_type_id = '';

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $dist = $_POST['dist'];

    $sql = "SELECT B_NAME FROM `block` WHERE `D_NAME` = '{$dist}' ORDER BY B_NAME";

    if ($result = $conn->query($sql)) {
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data .= '<option value="' . $row['B_NAME'] . '">' . $row['B_NAME'] . '</option>';
            }
        }
        $conn->close();
    }
}

echo $data;