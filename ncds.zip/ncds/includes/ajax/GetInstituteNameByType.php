<?php include('../db_config.php'); ?>
<?php

$data = '<option value="">Select</option>';
$institute_type_id = '';

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $institute_type_id = $_POST['institute_type_id'];

    $sql = "SELECT * FROM `tbl_master_institute` WHERE `institute_type_id` = {$institute_type_id} ORDER BY name";

    if ($result = $conn->query($sql)) {
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data .= '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
            }
        }
        $conn->close();
    }
}

echo $data;