<?php
$sql        = "SELECT CONCAT(MI.name, ' (', TRIM(MI.code), ')') AS institute, R.*  FROM tbl_records R";
$sql        .= " INNER JOIN tbl_master_institute MI ON MI.id = R.institute_id";
$sql        .= " WHERE R.id = " . $last_id . " AND R.user_id = " . $_SESSION['user_id'];
//$sql        .= " WHERE R.id = 2 AND R.user_id = 6";
$results    = $conn->query($sql);
$row        = $results->fetch_assoc();

if ($results->num_rows == 1)
{
?>
    <table id="exportTable" class="table table-bordered">
	
        <thead>
            <tr>
                <th>Field_Name</th>
                <th>Value</th>

            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Institute Name</td>
                <td><?php echo $row['institute']; ?></td>
            </tr>
			<tr>
                <td>District Name</td>
                <td><?php echo $row['D_NAME']; ?></td>
            </tr><tr>
                <td>Block Name</td>
                <td><?php echo $row['B_NAME']; ?></td>
            </tr>
			<tr>
                <td>Distance From District HQ</td>
                <td><?php echo $row['dist_hq']; ?></td>
            </tr>
			<tr>
                <td>Distance From Block HQ</td>
                <td><?php echo $row['block_hq']; ?></td>
            </tr>
            <?php
            if($_SESSION['institute_type_id'] != 1)
            {
                ?>
                <tr>
                    <td>No. of Girls enrolled in NSS</td>
                    <td><?php if($row['no_girls_nss'] != '')
                        {
                            echo $row['no_girls_nss'];
                        }
                        else {echo '0';}
                        ?>
                    </td>
                </tr>
                <tr>
                    <td>No. of Girls enrolled in NCC</td>
                    <td><?php if($row['no_girls_ncc'] != '')
                        {
                            echo $row['no_girls_ncc'];
                        }
                        else {echo '0';}
                        ?></td>
                </tr>
                <tr>
                    <td>No. of Girls trained in UAC(Un Armed Combat)</td>
                    <td><?php if($row['no_girls_uac'] != '')
                        {
                            echo $row['no_girls_uac'];
                        }
                        else {echo '0';}
                        ?></td>
                </tr>
				<tr>
                    <td>No. of YRC/ROVERS/RANGERS</td>
                    <td><?php if($row['no_yrc_rov'] != '')
                        {
                            echo $row['no_yrc_rov'];
                        }
                        else {echo '0';}
                        ?></td>
                </tr>
                <?php
            }
            ?>
            <tr>
                <td>No. of NET, Ph.D, M.Phil</td>
                <td><?php if($row['no_net_phd'] != '')
                    {
                        echo $row['no_net_phd'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Publications for last 3 years</td>
                <td><?php if($row['no_publications'] != '')
                    {
                        echo $row['no_publications'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Research Project Executed</td>
                <td><?php if($row['no_project_executed'] != '')
                    {
                        echo $row['no_project_executed'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of involving students in Research Projects(with valid evidence)</td>
                <td><?php if($row['no_students'] != '')
                    {
                        echo $row['no_students'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Regular Faculty</td>
                <td><?php if($row['no_faculty'] != '')
                    {
                        echo $row['no_faculty'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Classrooms</td>
                <td><?php if($row['no_class_rooms'] != '')
                    {
                        echo $row['no_class_rooms'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Laboratories</td>
                <td><?php if($row['no_lab'] != '')
                    {
                        echo $row['no_lab'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Computer Laboratories</td>
                <td><?php if($row['no_computer_lab'] != '')
                    {
                        echo $row['no_computer_lab'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Library Open Access</td>
                <td><?php if($row['no_library_open'] != '')
                    {
                        echo $row['no_library_open'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Library Digital</td>
                <td><?php if($row['no_library_digital'] != '')
                    {
                        echo $row['no_library_digital'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Drinking water Facilities(WORKING)</td>
                <td><?php if($row['no_drinking_water'] != '')
                    {
                        echo $row['no_drinking_water'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Toilet with running Water</td>
                <td><?php if($row['no_toilets'] != '')
                    {
                        echo $row['no_toilets'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Separate Toilet for Girls with running Water</td>
                <td><?php if($row['no_toilets_girls'] != '')
                    {
                        echo $row['no_toilets_girls'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Internal Complaints Committee(ICC)</td>
                <td><?php if($row['no_icc'] != '')
                    {
                        echo $row['no_icc'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Equal Opportunity Cell(EOC)</td>
                <td><?php if($row['no_grivances'] != '')
                    {
                        echo $row['no_grivances'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of Student Counseling</td>
                <td><?php if($row['no_student_counselling'] != '')
                    {
                        echo $row['no_student_counselling'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
			<tr>
                <td>No. of Antiraging/Sexual Harashment Cell</td>
                <td><?php if($row['no_antirag'] != '')
                    {
                        echo $row['no_antirag'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No. of E-Classrooms</td>
                <td><?php if($row['no_eclass_rooms'] != '')
                    {
                        echo $row['no_eclass_rooms'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
			<tr>
                <td>No. of Gym</td>
                <td><?php if($row['no_gym'] != '')
                    {
                        echo $row['no_gym'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
			<tr>
                    <td>Indoor Stadium (Yes/No)</td>
                    <td><?php if($row['indoor_stad'] != '1')
                        {
                            echo 'Yes';
                        }
                        else {echo 'No';}
                        ?></td>
            </tr>
			<tr>
                    <td>WIFI Campus (Yes/No)</td>
                    <td><?php if($row['wifi'] != '1')
                        {
                            echo 'Yes';
                        }
                        else {echo 'No';}
                        ?></td>
            </tr>
			<tr>
                    <td>Language Lab (Yes/No)</td>
                    <td><?php if($row['lang_lab'] != '1')
                        {
                            echo 'Yes';
                        }
                        else {echo 'No';}
                        ?></td>
            </tr>
			<tr>
                    <td>Smart Class (Yes/No)</td>
                    <td><?php if($row['smart_cls'] != '1')
                        {
                            echo 'Yes';
                        }
                        else {echo 'No';}
                        ?></td>
            </tr>
            <?php
            if($_SESSION['institute_type_id'] != 1) {
                ?>
                <tr>
                    <td>NCC (Yes/No)</td>
                    <td><?php if($row['ncc'] != '1')
                        {
                            echo 'Yes';
                        }
                        else {echo 'No';}
                        ?></td>
                </tr>
                <tr>
                    <td>NSS (Yes/No)</td>
                    <td><?php if($row['nss'] != '1')
                        {
                            echo 'Yes';
                        }
                        else {echo 'No';}
                        ?></td>
                </tr>
                <?php
            }
            ?>
            <tr>
                <td>Separate almanac for Sports Persons (Yes/No)</td>
                <td><?php if($row['separate_almanac'] != '1')
                    {
                        echo 'Yes';
                    }
                    else {echo 'No';}
                    ?></td>
            </tr>
            <tr>
                <td>Disabled friendly infrastructure (Yes/No)</td>
                <td><?php if($row['disabled_friendly_infra'] != '1')
                    {
                        echo 'Yes';
                    }
                    else {echo 'No';}
                    ?></td>
            </tr>
            <tr>
                <td>Skill Development Center (Yes/No)</td>
                <td><?php if($row['skill_dev_center'] != '1')
                    {
                        echo 'Yes';
                    }
                    else {echo 'No';}
                    ?></td>
            </tr>
            <tr>
                <td>No of Dropouts</td>
                <td><?php if($row['no_dropouts'] != '')
                    {
                        echo $row['no_dropouts'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>Transition rate (%)</td>
                <td><?php if($row['transition_rate'] != '')
                    {
                        echo $row['transition_rate'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>Re-admission rate (%)</td>
                <td><?php if($row['readmission_rat'] != '')
                    {
                        echo $row['readmission_rat'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>Placement rate (%)</td>
                <td><?php if($row['placement_rate'] != '')
                    {
                        echo $row['placement_rate'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>Self-employment (%)</td>
                <td><?php if($row['self_emp_rate'] != '')
                    {
                        echo $row['self_emp_rate'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>Students entering into Higher Education (%)</td>
                <td><?php if($row['student_entering_he_rate'] != '')
                    {
                        echo $row['student_entering_he_rate'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
			<tr>
                <td>Pass Percentage Male</td>
                <td><?php if($row['pass_male'] != '')
                    {
                        echo $row['pass_male'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
			<tr>
                <td>Pass Percentage Female</td>
                <td><?php if($row['pass_fmale'] != '')
                    {
                        echo $row['pass_fmale'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
			<tr>
                <td>Pass Percentage SC</td>
                <td><?php if($row['pass_sc'] != '')
                    {
                        echo $row['pass_sc'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
			<tr>
                <td>Pass Percentage ST</td>
                <td><?php if($row['pass_st'] != '')
                    {
                        echo $row['pass_st'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No of Separate Toilets</td>
                <td><?php if($row['no_seperate_toilet'] != '')
                    {
                        echo $row['no_seperate_toilet'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No of Ramps attached to classrooms</td>
                <td><?php if($row['no_ramps_classroom'] != '')
                    {
                        echo $row['no_ramps_classroom'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No of Ramps attached to library</td>
                <td><?php if($row['no_ramps_library'] != '')
                    {
                        echo $row['no_ramps_library'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
            <tr>
                <td>No of Teacher trained for Challenged</td>
                <td><?php if($row['no_teacher_trained'] != '')
                    {
                        echo $row['no_teacher_trained'];
                    }
                    else {echo '0';}
                    ?></td>
            </tr>
        </tbody>
    </table>
<?php
}