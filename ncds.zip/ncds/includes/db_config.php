<?php
/**
 * Created by PhpStorm.
 * User: PriyaRanjan
 * Date: 25-06-2017
 * Time: 08:06 PM
 */

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ncds";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    //die("Connection failed: " . $conn->connect_error);
    die("Connection failed: An error occured while connecting to database. Please try after sometime ! ");
}
