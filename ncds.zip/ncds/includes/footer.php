</div>
</div>
</div>
</body>

<script>
    $(document).ready(function () {
        $(".input-md2").keypress(function (e) {
            //if the letter is not digit then display error and don't type anything
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                //display error message
                alert ("Numbers only");
                return false;
            }
        });
        $(function(){
            var $select = $(".input-md1");
            for (i=0;i<=100;i++){
                $select.append($('<option></option>').val(i).html(i))
            }
        });
    });
</script>

</html>