<?php session_start(); ?>
<?php include('includes/db_config.php'); ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>NCD::College Data Collection</title>

        <script src="assets/js/jquery-2.1.4.min.js"></script>


        <!-- bootstrap for better look example, but not necessary -->
        <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css" type="text/css" media="screen, projection">

        <style>
            body { 
  background: url('http://www.publicdomainpictures.net/pictures/50000/velka/flower-meadow.jpg') no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
  
}
            #errmsg
            {
                color: red;
            }
            pre {margin: 45px 0 60px;}

            ul{
                cursor:pointer;
            }

            legend {
                color:#14b5c8;
            }
            #wizard_example {
                color:#285d30;
            }
            .nav-warning { background: #337ab7; color: #ffffff;  filter: alpha(opacity=50); /* internet explorer */
    -khtml-opacity: 0.9;      /* khtml, old safari */
    -moz-opacity: 0.9;       /* mozilla, netscape */
    opacity: 0.9;           /* fx, safari, opera */}
            .nav-warning a { color: #ffffff; }
            .nav>li>a:focus, .nav>li>a:hover {
                background-color: #337ab7;
            }
			.navbar-header {
    float: left;
    padding: 15px;
    text-align: center;
    width: 100%;
}
.navbar-brand {float:none;}
        </style>
    </head>
<body>
    <nav class="navbar nav-warning navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <span class="navbar-brand">Higher Education Department, Govt. of Odisha</span>
            </div>

        </div>
    </nav>
<div class="container"  style="background-color: #FFF; box-shadow: 0 1px 6px rgba(0, 0, 0, 0.12), 0 1px 4px rgba(0, 0, 0, 0.24);
">
    <div class="site-index">
    <div class="body-content">

<?php
if(
    isset($_SESSION['user_id']) &&
    isset($_SESSION['institute_type_id'])  &&
    isset($_SESSION['institute_type'])    &&
    isset($_SESSION['institute_id'])      &&
    isset($_SESSION['institute_name'])    &&
    isset($_SESSION['institute_code'])
)
{
    header("location: dashboard.php");
    exit;
}

$message = '';

if(isset($_POST['login_submit']))
{
	if($_POST['user_id']  && $_POST['user_pass'])
	{
		$user_id = $_POST['user_id'];
		$user_pass = $_POST['user_pass'];
		
		$sql        = "SELECT U.id AS user_id, U.password, MI.id AS institute_id, MI.`name` AS institute_name, TRIM(MI.`code`) AS institute_code, IT.id AS institute_type_id, IT.type AS institute_type FROM `tbl_users` U JOIN tbl_master_institute MI ON MI.`id` = U.institute_id JOIN tbl_institute_type IT ON MI.institute_type_id = IT.id WHERE U.user_id = '$user_id'";
		$results    = $conn->query($sql);
		$row        = $results->fetch_assoc();
		
		if ($results->num_rows == 1 && password_verify($user_pass, $row['password']))
		{
			$_SESSION['user_id']            = $row['user_id'];
			$_SESSION['institute_type_id']  = $row['institute_type_id'];
            $_SESSION['institute_type']     = $row['institute_type'];
            $_SESSION['institute_id']       = $row['institute_id'];
            $_SESSION['institute_name']     = $row['institute_name'];
            $_SESSION['institute_code']     = $row['institute_code'];
			
			header("location: dashboard.php");
			exit;
		} 
		else 
		{
			$message = "Your Login Name or Password is invalid";
		}
		$conn->close();
	}
	else
	{
		$message = "Please fill all the fields.";
	}
}
?>
    <div id="loginModal" class="modal show" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" style="margin-top: 130px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="text-center">Login</h1>
                </div>
                <div class="modal-body">
                    <?php
                        if(!empty($message)){ echo '<div class="alert alert-danger" role="alert">' . $message . '</div>';}
                    ?>
                    <form class="form col-md-12 center-block" method="POST" autocomplete="off" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                        <div class="form-group">
                            <input type="text" class="form-control input-lg" placeholder="User ID" name="user_id">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control input-lg" placeholder="Password" name="user_pass">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-lg btn-block" name="login_submit">Sign In</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <div class="col-md-12" style="text-align: center;">
                        <span><a href="register.php">Register</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
    </div>
</div>
</body>

</html>