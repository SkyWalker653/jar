<?php if(session_status() !== PHP_SESSION_ACTIVE) {session_start();} ?>
<?php
if(
    !isset($_SESSION['user_id']) &&
    !isset($_SESSION['institute_type_id'])  &&
    !isset($_SESSION['institute_type'])    &&
    !isset($_SESSION['institute_id'])      &&
    !isset($_SESSION['institute_name'])    &&
    !isset($_SESSION['institute_code'])
)
{
    header("location: logout.php");
    exit;
}
?>
<?php include('includes/header.php'); ?>
<?php
$record_enteres = FALSE;
$mode = '';
$last_id = 0;

$dist_name                  = '';
$block_name                 = '';
$dist_hq                    = '';
$block_hq                   = '';
$no_girls_nss               = '';
$no_girls_ncc               = '';
$no_girls_uac               = '';
$no_yrc_rov                 = '';
$no_net_phd                 = '';
$no_publications            = '';
$no_project_executed        = '';
$no_students                = '';
$no_faculty                 = '';
$no_class_rooms             = '';
$no_lab                     = '';
$no_computer_lab            = '';
$no_library_open            = '';
$no_library_digital         = '';
$no_drinking_water          = '';
$no_toilets                 = '';
$no_toilets_girls           = '';
$no_icc                     = '';
$no_grivances               = '';
$no_student_counselling     = '';
$no_antirag                 = '';
$no_eclass_rooms            = '';
$no_gym                     = '';
$indoor_stad                = '';
$wifi                       = '';
$lang_lab                   = '';
$smart_cls                  = '';
$ncc                        = '';
$nss                        = '';
$separate_almanac           = '';
$disabled_friendly_infra    = '';
$skill_dev_center           = '';
$no_dropouts                = '';
$transition_rate            = '';
$readmission_rat            = '';
$placement_rate             = '';
$self_emp_rate              = '';
$student_entering_he_rate   = '';
$pass_male                  = '';
$pass_fmale                 = '';
$pass_sc                    = '';
$pass_st                    = '';
$no_seperate_toilet         = '';
$no_ramps_classroom         = '';
$no_ramps_library           = '';
$no_teacher_trained         = '';

$sql_last_id = "SELECT id FROM tbl_records WHERE user_id = " . $_SESSION['user_id'] . " ORDER BY id DESC LIMIT 1";
$result_last_id = $conn->query($sql_last_id);
if($result_last_id->num_rows > 0)
{
    $record_enteres = TRUE;

    $row_last_id = $result_last_id->fetch_assoc();
    $last_id = $row_last_id['id'];
}

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $user_id                    = $_SESSION['user_id'];
    $institute_id               = $_SESSION['institute_id'];
    $institute_name             = $_SESSION['institute_name'];
    $institute_code             = $_SESSION['institute_code'];
    $dist_name                  = (isset($_POST['dist_name']) && !empty($_POST['dist_name'])) ? $_POST['dist_name'] : 'NULL';
    $block_name                 = (isset($_POST['block_name']) && !empty($_POST['block_name'])) ? $_POST['block_name'] : 'NULL';
    $dist_hq                    = (isset($_POST['dist_hq']) && !empty($_POST['dist_hq'])) ? $_POST['dist_hq'] : 'NULL';
    $block_hq                   = (isset($_POST['block_hq']) && !empty($_POST['block_hq'])) ? $_POST['block_hq'] : 'NULL';
    $no_girls_nss               = (isset($_POST['no_girls_nss']) && !empty($_POST['no_girls_nss'])) ? $_POST['no_girls_nss'] : 'NULL';
    $no_girls_ncc               = (isset($_POST['no_girls_ncc']) && !empty($_POST['no_girls_ncc'])) ? $_POST['no_girls_ncc'] : 'NULL';
    $no_girls_uac               = (isset($_POST['no_girls_uac']) && !empty($_POST['no_girls_uac'])) ? $_POST['no_girls_uac'] : 'NULL';
    $no_yrc_rov                 = (isset($_POST['no_yrc_rov']) && !empty($_POST['no_yrc_rov'])) ? $_POST['no_yrc_rov'] : 'NULL';
    $no_net_phd                 = (isset($_POST['no_net_phd']) && !empty($_POST['no_net_phd'])) ? $_POST['no_net_phd'] : 'NULL';
    $no_publications            = (isset($_POST['no_publications']) && !empty($_POST['no_publications'])) ? $_POST['no_publications'] : 'NULL';
    $no_project_executed        = (isset($_POST['no_publications']) && !empty($_POST['no_publications'])) ? $_POST['no_publications'] : 'NULL';
    $no_students                = (isset($_POST['no_students']) && !empty($_POST['no_students'])) ? $_POST['no_students'] : 'NULL';
    $no_faculty                 = (isset($_POST['no_faculty']) && !empty($_POST['no_faculty'])) ? $_POST['no_faculty'] : 'NULL';
    $no_class_rooms             = (isset($_POST['no_class_rooms']) && !empty($_POST['no_class_rooms'])) ? $_POST['no_class_rooms'] : 'NULL';
    $no_lab                     = (isset($_POST['no_lab']) && !empty($_POST['no_lab'])) ? $_POST['no_lab'] : 'NULL';$_POST['no_lab'];
    $no_computer_lab            = (isset($_POST['no_computer_lab']) && !empty($_POST['no_computer_lab'])) ? $_POST['no_computer_lab'] : 'NULL';
    $no_library_open            = (isset($_POST['no_library_open']) && !empty($_POST['no_library_open'])) ? $_POST['no_library_open'] : 'NULL';
    $no_library_digital         = (isset($_POST['no_library_digital']) && !empty($_POST['no_library_digital'])) ? $_POST['no_library_digital'] : 'NULL';
    $no_drinking_water          = (isset($_POST['no_drinking_water']) && !empty($_POST['no_drinking_water'])) ? $_POST['no_drinking_water'] : 'NULL';
    $no_toilets                 = (isset($_POST['no_toilets']) && !empty($_POST['no_toilets'])) ? $_POST['no_toilets'] : 'NULL';
    $no_toilets_girls           = (isset($_POST['no_toilets_girls']) && !empty($_POST['no_toilets_girls'])) ? $_POST['no_toilets_girls'] : 'NULL';
    $no_icc                     = (isset($_POST['no_icc']) && !empty($_POST['no_icc'])) ? $_POST['no_icc'] : 'NULL';
    $no_grivances               = (isset($_POST['no_grivances']) && !empty($_POST['no_grivances'])) ? $_POST['no_grivances'] : 'NULL';
    $no_student_counselling     = (isset($_POST['no_student_counselling']) && !empty($_POST['no_student_counselling'])) ? $_POST['no_student_counselling'] : 'NULL';
    $no_antirag                 = (isset($_POST['no_antirag']) && !empty($_POST['no_antirag'])) ? $_POST['no_antirag'] : 'NULL';
    $no_eclass_rooms            = (isset($_POST['no_eclass_rooms']) && !empty($_POST['no_eclass_rooms'])) ? $_POST['no_eclass_rooms'] : 'NULL';
    $no_gym                     = (isset($_POST['no_gym']) && !empty($_POST['no_gym'])) ? $_POST['no_gym'] : 'NULL';
    $indoor_stad                = (isset($_POST['indoor_stad']) && !empty($_POST['indoor_stad'])) ? $_POST['indoor_stad'] : 'NULL';
    $wifi                       = (isset($_POST['wifi']) && !empty($_POST['wifi'])) ? $_POST['wifi'] : 'NULL';
    $lang_lab                   = (isset($_POST['lang_lab']) && !empty($_POST['lang_lab'])) ? $_POST['lang_lab'] : 'NULL';
    $smart_cls                  = (isset($_POST['smart_cls']) && !empty($_POST['smart_cls'])) ? $_POST['smart_cls'] : 'NULL';
    $ncc                        = (isset($_POST['ncc']) && !empty($_POST['ncc'])) ? $_POST['ncc'] : 'NULL';
    $nss                        = (isset($_POST['nss']) && !empty($_POST['nss'])) ? $_POST['nss'] : 'NULL';
    $separate_almanac           = (isset($_POST['separate_almanac']) && !empty($_POST['separate_almanac'])) ? $_POST['separate_almanac'] : 'NULL';
    $disabled_friendly_infra    = (isset($_POST['disabled_friendly_infra']) && !empty($_POST['disabled_friendly_infra'])) ? $_POST['disabled_friendly_infra'] : 'NULL';
    $skill_dev_center           = (isset($_POST['skill_dev_center']) && !empty($_POST['skill_dev_center'])) ? $_POST['skill_dev_center'] : 'NULL';
    $no_dropouts                = (isset($_POST['no_dropouts']) && !empty($_POST['no_dropouts'])) ? $_POST['no_dropouts'] : 'NULL';
    $transition_rate            = (isset($_POST['transition_rate']) && !empty($_POST['transition_rate'])) ? $_POST['transition_rate'] : 'NULL';
    $readmission_rat            = (isset($_POST['readmission_rat']) && !empty($_POST['readmission_rat'])) ? $_POST['readmission_rat'] : 'NULL';
    $placement_rate             = (isset($_POST['placement_rate']) && !empty($_POST['placement_rate'])) ? $_POST['placement_rate'] : 'NULL';
    $self_emp_rate              = (isset($_POST['self_emp_rate']) && !empty($_POST['self_emp_rate'])) ? $_POST['self_emp_rate'] : 'NULL';
    $student_entering_he_rate   = (isset($_POST['student_entering_he_rate']) && !empty($_POST['student_entering_he_rate'])) ? $_POST['student_entering_he_rate'] : 'NULL';
    $pass_male                  = (isset($_POST['pass_male']) && !empty($_POST['pass_male'])) ? $_POST['pass_male'] : 'NULL';
    $pass_fmale                 = (isset($_POST['pass_fmale']) && !empty($_POST['pass_fmale'])) ? $_POST['pass_fmale'] : 'NULL';
    $pass_sc                    = (isset($_POST['pass_sc']) && !empty($_POST['pass_sc'])) ? $_POST['pass_sc'] : 'NULL';
    $pass_st                    = (isset($_POST['pass_st']) && !empty($_POST['pass_st'])) ? $_POST['pass_st'] : 'NULL';
    $no_seperate_toilet         = (isset($_POST['no_seperate_toilet']) && !empty($_POST['no_seperate_toilet'])) ? $_POST['no_seperate_toilet'] : 'NULL';
    $no_ramps_classroom         = (isset($_POST['no_ramps_classroom']) && !empty($_POST['no_ramps_classroom'])) ? $_POST['no_ramps_classroom'] : 'NULL';
    $no_ramps_library           = (isset($_POST['no_ramps_library']) && !empty($_POST['no_ramps_library'])) ? $_POST['no_ramps_library'] : 'NULL';
    $no_teacher_trained         = (isset($_POST['no_teacher_trained']) && !empty($_POST['no_teacher_trained'])) ? $_POST['no_teacher_trained'] : 'NULL';



    $sql = "INSERT INTO `tbl_records` (`user_id`, `institute_id`, `institute_name`, `institute_code`, `D_NAME`, `B_NAME`, `dist_hq`, `block_hq`, `no_girls_nss`, `no_girls_ncc`, `no_girls_uac`, `no_yrc_rov`, `no_net_phd`, `no_publications`, `no_project_executed`,
 `no_students`, `no_faculty`, `no_class_rooms`, `no_lab`, `no_computer_lab`, `no_library_open`, `no_library_digital`, `no_drinking_water`, `no_toilets`, `no_toilets_girls`,
  `no_icc`, `no_grivances`, `no_student_counselling`, `no_antirag`, `no_eclass_rooms`, `no_gym`, `indoor_stad`, `wifi`, `lang_lab`, `smart_cls`, `ncc`, `nss`, `separate_almanac`, `disabled_friendly_infra`, `skill_dev_center`, `no_dropouts`,
   `transition_rate`, `readmission_rat`, `placement_rate`, `self_emp_rate`, `student_entering_he_rate`, `pass_male`, `pass_fmale`, `pass_sc`, `pass_st`, `no_seperate_toilet`, `no_ramps_classroom`, `no_ramps_library`, `no_teacher_trained`) 
   VALUES (
        $user_id,
        $institute_id,
		'" . $institute_name . "',
		'" . $institute_code . "',
		'" . $dist_name . "',
		'" . $block_name . "',
		$dist_hq,
		$block_hq,
        $no_girls_nss,
        $no_girls_ncc,
        $no_girls_uac,
        $no_yrc_rov,
        $no_net_phd,
        $no_publications,
        $no_project_executed,
        $no_students,
        $no_faculty,
        $no_class_rooms,
        $no_lab,
        $no_computer_lab,
        $no_library_open,
        $no_library_digital,
        $no_drinking_water,
        $no_toilets,
        $no_toilets_girls,
        $no_icc,
        $no_grivances,
        $no_student_counselling,
        $no_antirag,
        $no_eclass_rooms,
        $no_gym,
        $indoor_stad,
        $wifi,
        $lang_lab,
        $smart_cls,
        $ncc,
        $nss,
        $separate_almanac,
        $disabled_friendly_infra,
        $skill_dev_center,
        $no_dropouts,
        $transition_rate,
        $readmission_rat,
        $placement_rate,
        $self_emp_rate,
        $student_entering_he_rate,
        $pass_male,
        $pass_fmale,
        $pass_sc,
        $pass_st,
        $no_seperate_toilet,
        $no_ramps_classroom,
        $no_ramps_library,
        $no_teacher_trained
   )";

    if ($conn->query($sql) === TRUE) {
        $record_enteres = TRUE;
		 $last_id = $conn->insert_id;
        ?>
        <div class="row">
            <div class="col-md-12" style="padding: 20px;">
                <div class="alert alert-success" role="alert">Data submitted successfully !<a class="alert alert-success" href="dashboard.php">View submitted Data</a></div>
				
            </div>
        </div>
        <?php
    } else {
        echo $message = '<div class="row"><div class="col-md-12"><div class="alert alert-danger" role="alert">ERROR: An error occured while saving data. Please refresh the page and try again !</div></div></div>';
        //echo $sql;
    }
}

// FETCH DATA FOR EDIT SECTION
if(isset($_REQUEST['mode']) && $_REQUEST['mode'] == 'edit')
{
    $mode = 'edit';

    $sql_record        = "SELECT CONCAT(MI.name, ' (', TRIM(MI.code), ')') AS institute, R.*  FROM tbl_records R";
    $sql_record        .= " INNER JOIN tbl_master_institute MI ON MI.id = R.institute_id";
    $sql_record        .= " WHERE R.id = " . $last_id . " AND R.user_id = " . $_SESSION['user_id'];
    //$sql        .= " WHERE R.id = 2 AND R.user_id = 6";
    $results_record     = $conn->query($sql_record);
    $row_record         = $results_record->fetch_assoc();

    if ($results_record->num_rows == 1) {
        $dist_name = $row_record['D_NAME'];
        $block_name = $row_record['B_NAME'];
        $dist_hq = $row_record['dist_hq'];
        $block_hq = $row_record['block_hq'];
        $no_girls_nss = $row_record['no_girls_nss'];
        $no_girls_ncc = $row_record['no_girls_ncc'];
        $no_girls_uac = $row_record['no_girls_uac'];
        $no_yrc_rov = $row_record['no_yrc_rov'];
        $no_net_phd = $row_record['no_net_phd'];
        $no_publications = $row_record['no_publications'];
        $no_project_executed = $row_record['no_project_executed'];
        $no_students = $row_record['no_students'];
        $no_faculty = $row_record['no_faculty'];
        $no_class_rooms = $row_record['no_class_rooms'];
        $no_lab = $row_record['no_lab'];
        $no_computer_lab = $row_record['no_computer_lab'];
        $no_library_open = $row_record['no_library_open'];
        $no_library_digital = $row_record['no_library_digital'];
        $no_drinking_water = $row_record['no_drinking_water'];
        $no_toilets = $row_record['no_toilets'];
        $no_toilets_girls = $row_record['no_toilets_girls'];
        $no_icc = $row_record['no_icc'];
        $no_grivances = $row_record['no_grivances'];
        $no_student_counselling = $row_record['no_student_counselling'];
        $no_antirag = $row_record['no_antirag'];
        $no_eclass_rooms = $row_record['no_eclass_rooms'];
        $no_gym = $row_record['no_gym'];
        $indoor_stad = $row_record['indoor_stad'];
        $wifi = $row_record['wifi'];
        $lang_lab = $row_record['lang_lab'];
        $smart_cls = $row_record['smart_cls'];
        $ncc = $row_record['ncc'];
        $nss = $row_record['nss'];
        $separate_almanac = $row_record['separate_almanac'];
        $disabled_friendly_infra = $row_record['disabled_friendly_infra'];
        $skill_dev_center = $row_record['skill_dev_center'];
        $no_dropouts = $row_record['no_dropouts'];
        $transition_rate = $row_record['transition_rate'];
        $readmission_rat = $row_record['readmission_rat'];
        $placement_rate = $row_record['placement_rate'];
        $self_emp_rate = $row_record['self_emp_rate'];
        $student_entering_he_rate = $row_record['student_entering_he_rate'];
        $pass_male = $row_record['pass_male'];
        $pass_fmale = $row_record['pass_fmale'];
        $pass_sc = $row_record['pass_sc'];
        $pass_st = $row_record['pass_st'];
        $no_seperate_toilet = $row_record['no_seperate_toilet'];
        $no_ramps_classroom = $row_record['no_ramps_classroom'];
        $no_ramps_library = $row_record['no_ramps_library'];
        $no_teacher_trained = $row_record['no_teacher_trained'];
    }
}



if($record_enteres == TRUE && $mode == '')
{
	$record_enteres = TRUE;
    ?>
    <div class="row">
        <div class="col-md-12" style="padding: 20px;">
            <div>
                <button class="btn btn-warning" id="exportButton">Download PDF</button>
                <a href="dashboard.php?mode=edit" class="btn btn-warning">Edit</a>
            </div>

            <div id="PrintContent">
                <?php include("includes/Report.php"); ?>
            </div>
        </div>
    </div>
    <?php
}


if($record_enteres == FALSE || $mode == 'edit')
{
?>

    <div class="row">
        <div class="col-md-12" style="padding: 20px;">
            <div style="margin: -20px -20px 20px; background: #2196F3; color: #fff; padding: 15px 20px;">
                <h4 style="margin: 0;"><?php echo $_SESSION['institute_type']; ?> Data Collection Wizard</h4>
            </div>

            <form id="wizard_example" action="" method="post" autocomplete="off">
                <fieldset>
                    <legend>Institute Name</legend>
                    <div id="div_id_username" class="form-group required">
                        <div class="controls col-md-12 ">
                            <p><?php echo $_SESSION['institute_name'] . ' (' . $_SESSION['institute_code'] . ')'; ?></p>
                        </div>
                    </div>

                    <div class="controls col-md-12 " id="responsecontainer" align="center"></div>
					<div id="div_id_username" class="form-group required">
                                <label for="nssgrls" class="control-label col-md-8  requiredField">District Name:<span class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <select class="form-control" name="dist_name" id="dist_name" required style="margin-bottom: 10px">
										<?php
										if($dist_name!='')
										{
										?>
										<option value="<?php echo $dist_name; ?>"><?php echo $dist_name; ?></option>
										<?php
										}
										?>
										<option value="">Select</option>

										 <?php
											$sql = "SELECT * FROM `district` ORDER BY D_NAME";
											if($result = $conn->query($sql))
											{
												if ($result->num_rows > 0) {
													// output data of each row
													while($row = $result->fetch_assoc()) {
														echo '<option value="' . $row['D_NAME'] . '">' . $row['D_NAME'] . '</option>';
													}
												} else {
													echo "0 results";
												}
												$conn->close();
											}
										?>

									</select>
                                </div>
                    </div>
					<div id="div_id_email" class="form-group">
						<label class="col-sm-8 control-label">Block Name</label>
						<div class="controls col-sm-4">
							<select class="form-control" name="block_name" id="block_name" required style="margin-bottom: 10px">
								<?php
										if($block_name!='')
										{
										?>
										<option value="<?php echo $block_name; ?>"><?php echo $block_name; ?></option>
										<?php
										}
								?>
								<option value="">Select</option>
							</select>
						</div>
					</div>
					
					<div id="div_id_email" class="form-group required">
						<label for="dist_hq" class="control-label col-md-8  requiredField">Distance From Dist_HQ:<span class="asteriskField"></span> </label>
						<div class="controls col-md-4 ">
							<input class="input-md2 emailinput form-control" id="dist_hq" value="<?php echo $dist_hq; ?>" name="dist_hq"  style="margin-bottom: 10px" type="text" placeholder="Distance from District HQ"/>
						</div>
                    </div>
							
					<div id="div_id_email" class="form-group required">
						<label for="block_hq" class="control-label col-md-8  requiredField">Distance From Block_HQ:<span class="asteriskField"></span> </label>
						<div class="controls col-md-4 ">
							<input class="input-md2 emailinput form-control" id="block_hq" value="<?php echo $block_hq; ?>" name="block_hq"  style="margin-bottom: 10px" type="text" placeholder="Distance from Block HQ"/>
						</div>
                    </div>

                    <?php
                        if($_SESSION['institute_type_id'] != 1)
                        {
                    ?>

                            <legend>Social Upliftment</legend>
							
                            <div id="div_id_email" class="form-group required">
                                <label for="nssgrl" class="control-label col-md-8  requiredField">No. of Girls enrolled in NSS:<span class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <input class="input-md2 emailinput form-control" id="nssgrl" value="<?php echo $no_girls_nss; ?>" name="no_girls_nss"  style="margin-bottom: 10px" type="text" placeholder="No. of Girls enrolled in NSS"/>
                                </div>
                            </div>
                            <div id="div_id_email" class="form-group required">
                                <label for="nccgrl" class="control-label col-md-8  requiredField">No. of Girls enrolled in NCC:<span class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <input class="input-md2 emailinput form-control" id="nccgrl" value="<?php echo $no_girls_ncc; ?>" name="no_girls_ncc"  style="margin-bottom: 10px" type="text" placeholder="No. of Girls enrolled in NCC"/>
                                </div>
                            </div>
                            <div id="div_id_email" class="form-group required">
                                <label for="uacgrl" class="control-label col-md-8  requiredField">No. of Girls trained in UAC(Un Armed Combat)/Self Defense:<span class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <input class="input-md2 emailinput form-control" id="uacgrl" value="<?php echo $no_girls_uac; ?>" name="no_girls_uac"  style="margin-bottom: 10px" type="text" placeholder="No. of Girls trained in UAC(Un Armed Combat)/Self Defense"/>
                                </div>
                            </div>
							<div id="div_id_email" class="form-group required">
                                <label for="yrcrov" class="control-label col-md-8  requiredField">No. of YRC/ROVERS/RANGERS:<span class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <input class="input-md2 emailinput form-control" id="yrcrov" value="<?php echo $no_yrc_rov; ?>" name="no_yrc_rov"  style="margin-bottom: 10px" type="text" placeholder="No. of YRC/ROVERS/RANGERS"/>
                                </div>
                            </div>

                    <?php
                        }
                    ?>

                    <legend>Teacher</legend>
                    <div id="div_id_email" class="form-group required">
                        <label for="net" class="control-label col-md-8  requiredField">No. of NET, Ph.D, M.Phil:<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="net" name="no_net_phd" style="margin-bottom: 10px">
							<?php
							if($no_net_phd!='')
							{
							?>
							<option value="<?php echo $no_net_phd; ?>"><?php echo $no_net_phd; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="nopubltn" class="control-label col-md-8  requiredField">No. of Publications(Books/Journals) for last 3 years:</label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="nopubltn" name="no_publications" style="margin-bottom: 10px">
							<?php
							if($no_publications!='')
							{
							?>
							<option value="<?php echo $no_publications; ?>"><?php echo $no_publications; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="rsrchproj" class="control-label col-md-8  requiredField">No. of Research Project Executed:<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="rsrchproj" name="no_project_executed" style="margin-bottom: 10px">
							<?php
							if($no_project_executed!='')
							{
							?>
							<option value="<?php echo $no_project_executed; ?>"><?php echo $no_project_executed; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="invlvstdnt" class="control-label col-md-8  requiredField">No. of involving students in Research Projects(with valid evidence):<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="invlvstdnt" name="no_students" style="margin-bottom: 10px">
							<?php
							if($no_students!='')
							{
							?>
							<option value="<?php echo $no_students; ?>"><?php echo $no_students; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="noregfac" class="control-label col-md-8  requiredField">No. of Regular Faculty:<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="noregfac" name="no_faculty" style="margin-bottom: 10px">
							<?php
							if($no_faculty!='')
							{
							?>
							<option value="<?php echo $no_faculty; ?>"><?php echo $no_faculty; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                </fieldset>
                <fieldset>
                    <legend>Infrastructure</legend>
                    <div id="div_id_email" class="form-group required">
                        <label for="noclsrm" class="control-label col-md-8  requiredField">No. of Classrooms:<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="noclsrm" name="no_class_rooms" style="margin-bottom: 10px">
							<?php
							if($no_class_rooms!='')
							{
							?>
							<option value="<?php echo $no_class_rooms; ?>"><?php echo $no_class_rooms; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="nocomplab" class="control-label col-md-8  requiredField">No. of Laboratories:<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="nocomplab" name="no_lab" style="margin-bottom: 10px">
							<?php
							if($no_lab!='')
							{
							?>
							<option value="<?php echo $no_lab; ?>"><?php echo $no_lab; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="nocomplab" class="control-label col-md-8  requiredField">No. of Computer Laboratories (WORKING):<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="nocomplab" name="no_computer_lab" style="margin-bottom: 10px">
							<?php
							if($no_computer_lab!='')
							{
							?>
							<option value="<?php echo $no_computer_lab; ?>"><?php echo $no_computer_lab; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="nolabopnac" class="control-label col-md-8  requiredField">No. of Library Open Access:<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="nolabopnac" name="no_library_open" style="margin-bottom: 10px">
							<?php
							if($no_library_open!='')
							{
							?>
							<option value="<?php echo $no_library_open; ?>"><?php echo $no_library_open; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="nolabdig" class="control-label col-md-8  requiredField">No. of Library Digital:<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="nolabdig" name="no_library_digital" style="margin-bottom: 10px">
							<?php
							if($no_library_digital!='')
							{
							?>
							<option value="<?php echo $no_library_digital; ?>"><?php echo $no_library_digital; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="nodrnkwtr" class="control-label col-md-8  requiredField">No. of Drinking water Facilities(WORKING)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="nodrnkwtr" name="no_drinking_water" style="margin-bottom: 10px">
							<?php
							if($no_drinking_water!='')
							{
							?>
							<option value="<?php echo $no_drinking_water; ?>"><?php echo $no_drinking_water; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="notltwtr" class="control-label col-md-8  requiredField">No. of Toilet with running Water<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="notltwtr" name="no_toilets" style="margin-bottom: 10px">
							<?php
							if($no_toilets!='')
							{
							?>
							<option value="<?php echo $no_toilets; ?>"><?php echo $no_toilets; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="nosprttoil" class="control-label col-md-8  requiredField">No. of Separate Toilet for Girls with running Water<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="nosprttoil" name="no_toilets_girls" style="margin-bottom: 10px">
							<?php
							if($no_toilets_girls!='')
							{
							?>
							<option value="<?php echo $no_toilets_girls; ?>"><?php echo $no_toilets_girls; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="noicc" class="control-label col-md-8  requiredField">No. of Internal Redressal Cell(IRC)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="noicc" name="no_icc" style="margin-bottom: 10px">
							<?php
							if($no_icc!='')
							{
							?>
							<option value="<?php echo $no_icc; ?>"><?php echo $no_icc; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="nogriev" class="control-label col-md-8  requiredField">No. of Equal Opportunity Cell(EOC)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="nogriev" name="no_grivances" style="margin-bottom: 10px">
							<?php
							if($no_grivances!='')
							{
							?>
							<option value="<?php echo $no_grivances; ?>"><?php echo $no_grivances; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="nostdntcnsl" class="control-label col-md-8  requiredField">No. of Student Counseling<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="nostdntcnsl" name="no_student_counselling" style="margin-bottom: 10px">
							<?php
							if($no_student_counselling!='')
							{
							?>
							<option value="<?php echo $no_student_counselling; ?>"><?php echo $no_student_counselling; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
					<div id="div_id_email" class="form-group required">
                        <label for="no_antirag" class="control-label col-md-8  requiredField">No. of Anti-Ragging/Sexual Harashment Cell<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="no_antirag" name="no_antirag" style="margin-bottom: 10px">
							<?php
							if($no_antirag!='')
							{
							?>
							<option value="<?php echo $no_antirag; ?>"><?php echo $no_antirag; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="noeclsrm" class="control-label col-md-8  requiredField">No. of E-Classrooms<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="noeclsrm" name="no_eclass_rooms" style="margin-bottom: 10px">
							<?php
							if($no_eclass_rooms!='')
							{
							?>
							<option value="<?php echo $no_eclass_rooms; ?>"><?php echo $no_eclass_rooms; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
					 <div id="div_id_email" class="form-group required">
                        <label for="no_gym" class="control-label col-md-8  requiredField">No. of Gym<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="no_gym" name="no_gym" style="margin-bottom: 10px">
							<?php
							if($no_gym!='')
							{
							?>
							<option value="<?php echo $no_gym; ?>"><?php echo $no_gym; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
					<div id="div_id_email" class="form-group required">
                                <label for="indoor_stad" class="control-label col-md-8  requiredField">Indoor Stadium (Yes/No)<span
                                            class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <select class="input-md emailinput form-control" id="indoor_stad" name="indoor_stad" 
                                            style="margin-bottom: 10px" required="" data-parsley-group="block1">
											<?php
											if($indoor_stad!='')
											{
											?>
                                        <option value="<?php echo $indoor_stad; ?>">
										<?php
											if($indoor_stad='0')
											{
												echo "Yes";
											}
											elseif($indoor_stad='1')
											{
												echo "No";
											}
										?>
										</option>
										<?php
											}
											?>
                                        <option value="">---</option>
                                        <option value="1">Yes</option>
                                        <option value="0">No</option>
                                    </select>
                                </div>
                    </div>
					<div id="div_id_email" class="form-group required">
                                <label for="wifi" class="control-label col-md-8  requiredField">WI-FI Campus (Yes/No)<span
                                            class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <select class="input-md emailinput form-control" id="wifi" name="wifi" 
                                            style="margin-bottom: 10px" required="" data-parsley-group="block1">
											<?php
											if($wifi!='' && !empty($wifi) && $wifi != null)
											{
											?>
                                        <option value="<?php echo $wifi; ?>">
										<?php
											if($wifi='0')
											{
												echo "Yes";
											}
											elseif($wifi='1')
											{
												echo "No";
											}
										?>
										</option>
										<?php
											}
											?>
                                        <option value="">---</option>
                                        <option value="1">Yes</option>
                                        <option value="0">No</option>
                                    </select>
                                </div>
                    </div>
					<div id="div_id_email" class="form-group required">
                                <label for="lang_lab" class="control-label col-md-8  requiredField">Language Lab (Yes/No)<span
                                            class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <select class="input-md emailinput form-control" id="lang_lab" name="lang_lab" 
                                            style="margin-bottom: 10px" required="" data-parsley-group="block1">
											<?php
											if($lang_lab!='')
											{
											?>
                                        <option value="<?php echo $lang_lab; ?>">
										<?php
											if($lang_lab='0')
											{
												echo "Yes";
											}
											elseif($lang_lab='1')
											{
												echo "No";
											}
										?>
										</option>
										<?php
											}
											?>
                                        <option value="">---</option>
                                        <option value="1">Yes</option>
                                        <option value="0">No</option>
                                    </select>
                                </div>
                    </div>
					<div id="div_id_email" class="form-group required">
                                <label for="smart_cls" class="control-label col-md-8  requiredField">Smart Class (Yes/No)<span
                                            class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <select class="input-md emailinput form-control" id="smart_cls" name="smart_cls" 
                                            style="margin-bottom: 10px" required="" data-parsley-group="block1">
											<?php
											if($smart_cls!='')
											{
											?>
                                        <option value="<?php echo $smart_cls; ?>">
										<?php
											if($smart_cls='0')
											{
												echo "Yes";
											}
											elseif($smart_cls='1')
											{
												echo "No";
											}
										?>
										</option>
										<?php
											}
											?>
                                        <option value="">---</option>
                                        <option value="1">Yes</option>
                                        <option value="0">No</option>
                                    </select>
                                </div>
                    </div>
					
					
					

                    <?php
                        if($_SESSION['institute_type_id'] != 1) {
                    ?>
                            <div id="div_id_email" class="form-group required">
                                <label for="ncc" class="control-label col-md-8  requiredField">NCC (Yes/No)<span
                                            class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <select class="input-md emailinput form-control" id="ncc" name="ncc" 
                                            style="margin-bottom: 10px" required="" data-parsley-group="block1">
											<?php
											if($ncc!='')
											{
											?>
                                        <option value="<?php echo $ncc; ?>">
										<?php
											if($ncc='0')
											{
												echo "Yes";
											}
											elseif($ncc='1')
											{
												echo "No";
											}
										?>
										</option>
										<?php
											}
											?>
                                        <option value="">---</option>
                                        <option value="1">Yes</option>
                                        <option value="0">No</option>
                                    </select>
                                </div>
                            </div>
                            <div id="div_id_email" class="form-group required">
                                <label for="nss" class="control-label col-md-8  requiredField">NSS (Yes/No)<span
                                            class="asteriskField"></span> </label>
                                <div class="controls col-md-4 ">
                                    <select class="input-md emailinput form-control" id="nss" name="nss" value="<?php echo $nss; ?>"
                                            style="margin-bottom: 10px" required="" data-parsley-group="block1">
											<?php
											if($nss!='')
											{
											?>
                                        <option value="<?php echo $nss; ?>">
										<?php
											if($nss='0')
											{
												echo "Yes";
											}
											elseif($nss='1')
											{
												echo "No";
											}
										?>
										</option>
										<?php
											}
											?>
                                        <option value="">---</option>
                                        <option value="1">Yes</option>
                                        <option value="0">No</option>
                                    </select>
                                </div>
                            </div>
                    <?php
                        }
                    ?>

                    <div id="div_id_email" class="form-group required">
                        <label for="separate_almanac" class="control-label col-md-8  requiredField">Separate almanac for Sports Persons (Yes/No)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md emailinput form-control" id="separate_almanac" name="separate_almanac" style="margin-bottom: 10px" required="" data-parsley-group="block1">
							<?php
											if($separate_almanac!='')
											{
											?>
                                        <option value="<?php echo $separate_almanac; ?>">
										<?php
											if($separate_almanac='0')
											{
												echo "Yes";
											}
											elseif($separate_almanac='1')
											{
												echo "No";
											}
										?>
										</option>
										<?php
											}
											?>
                                <option value="">---</option>
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="disinfra" class="control-label col-md-8  requiredField">Disabled friendly infrastructure (Yes/No)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md emailinput form-control" id="disinfra" name="disabled_friendly_infra" style="margin-bottom: 10px" required="" data-parsley-group="block1">
                                <?php
											if($disabled_friendly_infra!='')
											{
											?>
                                        <option value="<?php echo $disabled_friendly_infra; ?>">
										<?php
											if($disabled_friendly_infra='0')
											{
												echo "Yes";
											}
											elseif($disabled_friendly_infra='1')
											{
												echo "No";
											}
										?>
										</option>
										<?php
											}
											?>
								<option value="">---</option>
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="skldevcen" class="control-label col-md-8  requiredField">Skill Development Center (Yes/No)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md emailinput form-control" id="skldevcen" name="skill_dev_center" style="margin-bottom: 10px" required="" data-parsley-group="block1">
                                <?php
											if($skill_dev_center!='')
											{
											?>
                                        <option value="<?php echo $skill_dev_center; ?>">
										<?php
											if($skill_dev_center='0')
											{
												echo "Yes";
											}
											elseif($skill_dev_center='1')
											{
												echo "No";
											}
										?>
										</option>
										<?php
											}
											?>
								<option value="">---</option>
                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>
                        </div>
                    </div>
                </fieldset>
                <fieldset>
                    <legend>Outcome</legend>
                    <div id="div_id_email" class="form-group required">
                        <label for="nodrop" class="control-label col-md-8  requiredField">No of Dropouts<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="nodrop" value="<?php echo $no_dropouts; ?>" name="no_dropouts" style="margin-bottom: 10px" type="text" placeholder="No of Dropouts"/>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="trnsrat" class="control-label col-md-8  requiredField">Transition rate (%)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="trnsrat" value="<?php echo $transition_rate; ?>" name="transition_rate" style="margin-bottom: 10px" type="text" placeholder="Transition rate (%)"/>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="readrat" class="control-label col-md-8  requiredField">Re-admission rate (%)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="readrat" value="<?php echo $readmission_rat; ?>" name="readmission_rat" style="margin-bottom: 10px" type="text" placeholder="Re-admission rate (%)"/>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="plcrat" class="control-label col-md-8  requiredField">Placement rate (%)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="plcrat" value="<?php echo $placement_rate; ?>" name="placement_rate" style="margin-bottom: 10px" type="text" placeholder="Placement rate (%)"/>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="slfrat" class="control-label col-md-8  requiredField">Self-employment (%)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="slfrat" value="<?php echo $self_emp_rate; ?>" name="self_emp_rate" style="margin-bottom: 10px" type="text" placeholder="Rate Self-employment (%)"/>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="stdrat" class="control-label col-md-8  requiredField">Students entering into Higher Education (%)<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="stdrat" value="<?php echo $student_entering_he_rate; ?>" name="student_entering_he_rate" style="margin-bottom: 10px" type="text" placeholder="Rate of students entering into Higher Education (%)"/>
                        </div>
                    </div>
					<div id="div_id_email" class="form-group required">
                        <label for="pass_male" class="control-label col-md-8  requiredField">Pass Percentage Male<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="pass_male" value="<?php echo $pass_male; ?>" name="pass_male" style="margin-bottom: 10px" type="text" placeholder="Pass Percentage Male"/>
                        </div>
                    </div>
					<div id="div_id_email" class="form-group required">
                        <label for="pass_fmale" class="control-label col-md-8  requiredField">Pass Percentage Female<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="pass_fmale" value="<?php echo $pass_fmale; ?>" name="pass_fmale" style="margin-bottom: 10px" type="text" placeholder="Pass Percentage Female"/>
                        </div>
                    </div>
					<div id="div_id_email" class="form-group required">
                        <label for="pass_sc" class="control-label col-md-8  requiredField">Pass Percentage SC<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="pass_sc" value="<?php echo $pass_sc; ?>" name="pass_sc" style="margin-bottom: 10px" type="text" placeholder="Pass Percentage SC"/>
                        </div>
                    </div>
					<div id="div_id_email" class="form-group required">
                        <label for="pass_st" class="control-label col-md-8  requiredField">Pass Percentage ST<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <input class="input-md2 emailinput form-control" id="pass_st" value="<?php echo $pass_st; ?>" name="pass_st" style="margin-bottom: 10px" type="text" placeholder="Pass Percentage ST"/>
                        </div>
                    </div>
                    <legend>Facilities for Disable</legend>
                    <div id="div_id_email" class="form-group required">
                        <label for="noseptoi" class="control-label col-md-8  requiredField">No of Separate Toilets<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="noseptoi" name="no_seperate_toilet" style="margin-bottom: 10px">
							<?php
							if($no_seperate_toilet!='')
							{
							?>
							<option value="<?php echo $no_seperate_toilet; ?>"><?php echo $no_seperate_toilet; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="normpcls" class="control-label col-md-8  requiredField">No of Ramps attached to classrooms<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="normpcls" name="no_ramps_classroom" style="margin-bottom: 10px">
							<?php
							if($no_ramps_classroom!='')
							{
							?>
							<option value="<?php echo $no_ramps_classroom; ?>"><?php echo $no_ramps_classroom; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="normplib" class="control-label col-md-8  requiredField">No of Ramps attached to Library<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="normplib" name="no_ramps_library" style="margin-bottom: 10px">
							<?php
							if($no_ramps_library!='')
							{
							?>
							<option value="<?php echo $no_ramps_library; ?>"><?php echo $no_ramps_library; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <div id="div_id_email" class="form-group required">
                        <label for="notchchl" class="control-label col-md-8  requiredField">No of Teacher trained for Challenged<span class="asteriskField"></span> </label>
                        <div class="controls col-md-4 ">
                            <select class="input-md1 emailinput form-control" id="notchchl" name="no_teacher_trained" style="margin-bottom: 10px">
							<?php
							if($no_teacher_trained!='')
							{
							?>
							<option value="<?php echo $no_teacher_trained; ?>"><?php echo $no_teacher_trained; ?></option>
							<?php
							}
							?>
							</select>
                        </div>
                    </div>
                    <noscript>
                        <input class="nocsript-finish-btn sf-right nocsript-sf-btn" type="submit" value="finish"/>
                    </noscript>
                </fieldset>
            </form>
        </div>
    </div>

<?php
}
?>
<script>
    $(document).ready(function(){
        $("#dist_name").change(function(){
            var dist = this.value;
            $.post("includes/ajax/Getblock.php",
                {
                    dist: dist
                },
                function(data,status){
                    $("#block_name").html(data);
                });

           
        });
	});
</script>
<?php include('includes/footer.php'); ?>
