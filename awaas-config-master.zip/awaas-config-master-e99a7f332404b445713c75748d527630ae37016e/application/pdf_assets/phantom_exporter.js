var system = require('system');
var args = system.args;
var export_file = args[1];
var template_file = args[2];
var base_url = args[3];


var page = require('webpage').create();
page.paperSize = {
  format: 'A4',
  orientation: 'portrait',
  margin: '1cm',
  footer: {
    height: "1cm",
    contents: phantom.callback(function(pageNum, numPages) { 
        // return "<span style='float:right;font-size: 8px;color:grey'> Page " + pageNum + " of " + numPages + " Powered By NIC </span>";
    })
  }
}
page.viewportSize = {
  width: 2000, height: 7100
}

page.onResourceRequested = function(requestData, request) {
  console.log('::loading', requestData['url']);  // this does get logged now
};

page.onConsoleMessage = function(msg) {
  console.log('CONSOLE: ' + msg);
};

page.onLoadFinished = function() {    

  page.evaluate(function(){
    // fixing 
    function process(rule) {
      if(rule.cssRules) {          
        for(var i=rule.cssRules.length-1; i>=0; i--) { 
          process(rule.cssRules[i]);
        }
      }
      if(rule.type == CSSRule.MEDIA_RULE) {
        if(window.matchMedia(rule.media.mediaText).matches) {
          rule.media.mediaText = "all";          
        } else {
          rule.media.mediaText = "not all";          
        }
      }
      return rule;
    }    
    for(var i=0; i<document.styleSheets.length; i++) { 
      process(document.styleSheets[i]);
    }

  })

  console.log('::rendering');
  page.render(args[1] );    
  phantom.exit();
};

page.onError = function (msg, trace) {
  console.log(msg);
  trace.forEach(function(item) {
    console.log('  ', item.file, ':', item.line);
  });
};

page.onResourceError = function(resourceError) {
  page.reason = resourceError.errorString;
  page.reason_url = resourceError.url;
};

var fs = require('fs');
var content = fs.read(template_file);



page.setContent(content, base_url);
