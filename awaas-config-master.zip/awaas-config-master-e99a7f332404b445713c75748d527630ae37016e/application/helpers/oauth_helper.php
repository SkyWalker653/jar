<?php
defined('BASEPATH') OR exit('No direct script access allowed');


if ( ! function_exists('get_access_token')){
	function get_access_token($code, $token_url, $client_id, $secret, $Scope, $redirect) {
		$fields = array(
			'client_id' => $client_id,
			'client_secret' => $secret,
			'grant_type' => 'authorization_code',
			'scope' => $Scope,
			'code' => $code,
			'redirect_uri' => $redirect,
			);
		$post_data = rawurldecode(http_build_query( $fields ));
  //open connection
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL, $token_url);
		curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, false );
		curl_setopt( $ch, CURLOPT_HEADER, false );
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_POST, true );
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $post_data );
  //execute post
		$result = curl_exec($ch);

  //close connection
		curl_close($ch);
		return $result;
	}
}

if ( ! function_exists('get_uuid')){
	function get_uuid($access_code, $tokens_url) {
  //open connection
		$ch = curl_init();
		$tokens_url .= "/$access_code";
		curl_setopt($ch,CURLOPT_URL, $tokens_url);
		curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, false );
		curl_setopt( $ch, CURLOPT_HEADER, false );
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_POST, false );
  //execute post
		$result = curl_exec($ch);

  //close connection
		curl_close($ch);
		return $result;
	}
}
if ( ! function_exists('dump_var')){
	function get_profile_data($access_token, $url) {
		$headers = array();
		$headers[] = 'Authorization: Bearer ' . $access_token;

		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, false );
		curl_setopt( $ch, CURLOPT_HEADER, false );
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_POST, false );
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);


  //execute post
		$result = curl_exec($ch);

  //close connection
		curl_close($ch);
		return $result;
	}

}
