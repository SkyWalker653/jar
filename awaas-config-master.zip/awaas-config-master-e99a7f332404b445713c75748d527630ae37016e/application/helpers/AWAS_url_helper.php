<?php

if (!function_exists('loadLibrary')) {

  function loadLibrary($libraryName) {
    $ci = & get_instance();
    $ci->load->library($libraryName);
    return $ci->$libraryName;
  }
}
