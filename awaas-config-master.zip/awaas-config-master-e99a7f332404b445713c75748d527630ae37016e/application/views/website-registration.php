<div class="container">
  <!--<form class="form-horizontal">-->
  <?php echo form_open('site/register', array('class'=>'form-horizontal')); ?>
    <input type="hidden" name='step' value='0'/>
    
    <div class="row">
      <div class="col-md-12">      
        <ul id='registration' class="nav nav-tabs">
          <li role="presentation"><a href="#select-template"><strong class="text-center" style="font-size: 1.2em">1 - </strong> Select Template</a></li>
          <li role="presentation"><a href="#site-details"><strong class="text-center" style="font-size: 1.2em">2 - </strong> Website Details</a></li>          
          <li role="presentation"><a href="#technical-details"><strong class="text-center" style="font-size: 1.2em">3 - </strong>Technical Details</a></li>
          <li role="presentation"><a href="#owner-details"><strong class="text-center" style="font-size: 1.2em">4 - </strong>Site Owner Details</a></li>
        </ul>
        <div class="tab-content">
          <div class="tab-pane fade" id="select-template">
            <div class="panel panel-primary">  
              <div class="panel-body">
                <legend class="text-center text-primary">Select Template</legend> 
                <input type="hidden" name='template' value='-1'/>
                <div class="theme-boxes clearfix">
                  
                </div>                
              </div>
              <div class="panel-footer hidden">
                <div class="row">
                  <div class="col-md-2 ">
                    <button type="button" class="btn btn-warning pull-right">Cancel</button>
                  </div>
                  <div class="col-md-2 col-md-offset-8 ">
                    <button type='submit' class=" btn btn-primary pull-right">Proceed to Website Details</button>
                  </div>
                </div>
              </div>
            </div>
          </div>          
          <div class="tab-pane fade" id="site-details">
            <div class="panel panel-primary">       
              <div class="panel-body">
                <legend class="text-center text-primary">WebSite Details</legend>  
                
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="site_name">Name of Website</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" name='site_name' id="site_name" placeholder="Name of Website">
                    <span class="help-block">
                      <span class="default">Name can be space separated<span class="text-danger">  (mandatory) </span></span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="site_domain">Domain/URL of Website </label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" name='site_domain' id="site_domain" placeholder="Domain/URL of Website">                    
                    <span class="help-block">
                      <span class="default">A valid domain URL (include http:// or https://)<span class="text-danger">  (mandatory) </span></span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="site_dc">Data Centre(Hosting Preference)</label>
                  <div class="col-sm-9 col-md-10">
                    <select class="form-control" id="site_dc"  name='site_dc' placeholder="Data Centre">
                      <option value="-1">--Select Among Options--</option>
                      
                    </select>
                    <!--<input type="text" class="form-control" id="site_dc"  name='site_dc' placeholder="Data Centre">-->
                    <span class="help-block">
                      <span class="default">Choose Among mentioned Data Centre <small class="text-muted">(Availability rights reserved with AWAAS)</small><span class="text-danger">  (mandatory) </span></span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>            
              </div>
              <div class="panel-footer">
                <div class="row">
                  <div class="col-md-2 ">
                    <button type="button" class="btn btn-warning pull-right">Cancel</button>
                  </div>
                  <div class="col-md-2 col-md-offset-8 ">
                    <button type='submit' class=" btn btn-primary pull-right">Proceed to Technical Details</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="tab-pane fade" id="technical-details">
            <div class="panel panel-primary">       
              <div class="panel-body">
                <legend class="text-center text-primary">Technical Details <small>(Your Details)</small></legend>                 
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="te_name" >Name</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="te_name" name="te_name" placeholder="Enter Applicant Name">
                    <span class="help-block">
                      <span class="default">Name can be space separated, no need to add <strong>Mr, Mrs or Miss</strong></span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="te_email">Email</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="te_email" name="te_email" placeholder="Enter Applicant Email">
                    <span class="help-block">
                      <span class="default">A valid official mail ID correspondence will be done on mentioned mail ID.</span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="te_org">Organization</label>
                  <div class="col-sm-9 col-md-10">
                    <select class="form-control organizations" id="te_org" name="te_org" placeholder="Enter Applicant Organization">
                      <option value="-1">--Select Among Options--</option>                      
                    </select>                    
                    <span class="help-block">
                      <span class="default">Enter Full name of organization, avoid abbreviations. </span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="te_name">Address</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="te_addr" name="te_addr" placeholder="Enter Applicant Address">
                    <span class="help-block">
                      <span class="default">Full Address of Applicant</span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="te_state">State</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="te_state" name="te_state" placeholder="Enter Applicant State">
                    <span class="help-block">                      
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="te_pincode">Pincode</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="te_pincode" name="te_pincode" placeholder="Enter Applicant Address Pincode">
                    <span class="help-block">
                      <span class="default">Pincode should be 6 digit number of your locality.</span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>                
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="te_name">Telephone</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="te_telephone" name="te_telephone" placeholder="Enter Applicant Telephone Number">
                    <span class="help-block">
                      <span class="default">Landline Number, Add STD code as prefix!</span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="te_mobile">Mobile</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="te_mobile" name="te_mobile" placeholder="Enter Applicant's mobile Number">
                    <span class="help-block">
                      <span class="default">10 digit Mobile number, no need to prefix <strong>+91</strong> or <strong>0</strong></span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>                        
              </div>
              <div class="panel-footer">
                <div class="row">
                  <div class="col-md-2 ">
                    <a class="btn btn-danger wiz-link" href="#applicant-details" role="button">Back to Applicant Details</a> 
                  </div>
                  <div class="col-md-2 col-md-offset-8 ">
                    <button type='submit' class=" btn btn-primary pull-right">Proceed to Site Owner Details</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="owner-details">
            <div class="panel panel-primary">       
              <div class="panel-body">
                <legend class="text-center text-primary">Owner Details <small>(Responsible for Site Content and will Sign Auth letter)</small></legend>                 
                <div class="form-group">
                  
                  <label class="col-sm-3 col-md-2 control-label" for="owner_name" >Name</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="owner_name" name="owner_name" placeholder="Enter Applicant Name">
                    <span class="help-block">
                      <span class="default">Name can be space separated, no need to add <strong>Mr, Mrs or Miss</strong></span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="owner_email">Email</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="owner_email" name="owner_email" placeholder="Enter Applicant Email">
                    <span class="help-block">
                      <span class="default">A valid official mail ID correspondence will be done on mentioned mail ID.</span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="owner_org">Organization</label>
                  <div class="col-sm-9 col-md-10">
                    <select class="form-control organizations" id="owner_org" name="owner_org" placeholder="Enter Applicant Organization">
                      <option value="-1">--Select Among Options--</option>                      
                    </select>                    
                    <span class="help-block">
                      <span class="default">Enter Full name of organization, avoid abbreviations. </span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="owner_name">Address</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="owner_addr" name="owner_addr" placeholder="Enter Applicant Address">
                    <span class="help-block">
                      <span class="default">Full Address of Applicant</span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="owner_state">State</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="owner_state" name="owner_state" placeholder="Enter Applicant State">
                    <span class="help-block">                      
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="owner_pincode">Pincode</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="owner_pincode" name="owner_pincode" placeholder="Enter Applicant Address Pincode">
                    <span class="help-block">
                      <span class="default">Pincode should be 6 digit number of your locality.</span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="owner_name">Telephone</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="owner_telephone" name="owner_telephone" placeholder="Enter Applicant Telephone Number">
                    <span class="help-block">
                      <span class="default">Landline Number, Add STD code as prefix!</span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 col-md-2 control-label" for="owner_mobile">Mobile</label>
                  <div class="col-sm-9 col-md-10">
                    <input type="text" class="form-control" id="owner_mobile" name="owner_mobile" placeholder="Enter Applicant's mobile Number">
                    <span class="help-block">
                      <span class="default">10 digit Mobile number, no need to prefix <strong>+91</strong> or <strong>0</strong></span>
                      <span class='validation hidden'></span>
                    </span>
                  </div>
                </div>                        
              </div>
              <div class="panel-footer">
                <div class="row">
                  <div class="col-md-2 pull">
                    <a class="btn btn-danger wiz-link" href="#technical-details" role="button">Back to Technical Details</a>                    
                  </div>
                  <div class="col-md-2 col-md-offset-8 ">
                    <button type="submit" class=" btn btn-primary pull-right">Submit</button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </form>
</div>
<script src="/assets/js/async.js"></script>
<script src="/assets/js/moment.js"></script>
<script src="/assets/js/select2.js"></script>
<script src="/assets/js/site-registration.js"></script>
<link rel="stylesheet" type="text/css" href="/assets/css/select2.css">