<section class="page-content less-padding">
  <div class="container">
    <h3 class="heading2 no-sites hidden">Seems you don't have Any Site, Click <a href="/site/register" class="btn bg-red text-uppercase text-white btn2">Build a New  Site </a> to create One!!</h3>
    
    <div class="active-site-list hidden">
      <h3 class="heading2">My Websites </h3>
      <div class="row active-sites hidden">
        <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
          <div class="site-thumb">
            <img src="images/theme3.jpg">
          </div>
        </div>

        <div class="col-lg-7  col-md-6  col-sm-6  col-xs-12">
          <h4>Ministry of Culture	</h4>
          <p>URL: http://www.indiaculture.nic.in</p>
          <h5>Theme Name</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut condimentum commodo facilisis. Donec scelerisque dignissim pulvinar. Curabitur </p>
          <table>
            <tbody>
              <tr>
                <td>Created:  </td>
                <td>10th Jan 2014</td>
              </tr>
              <tr>
                <td>Last Update: </td>
                <td> 6th April 2015</td>
              </tr>
            </tbody>
          </table>

          <a href="#" class="btn btn-info">Edit  Website   <i class="fa fa-pencil"></i> </a>
        </div>
      </div>

      <div class="row active-sites hidden">
        <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
          <div class="site-thumb">
            <img src="images/theme4.jpg">
          </div>
        </div>

        <div class="col-lg-7  col-md-6  col-sm-6  col-xs-12">
          <h4>Ministry of Culture	</h4>
          <p>URL: http://www.indiaculture.nic.in</p>
          <h5>Theme Name</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut condimentum commodo facilisis. Donec scelerisque dignissim pulvinar. Curabitur </p>
          <table>
            <tbody>
              <tr>
                <td>Created:  </td>
                <td>10th Jan 2014</td>
              </tr>
              <tr>
                <td>Last Update: </td>
                <td> 6th April 2015</td>
              </tr>
            </tbody>
          </table>

          <a href="#" class="btn btn-info">Edit  Website   <i class="fa fa-pencil"></i> </a>
        </div>
      </div>
    </div>
  </div>

</div>
</section>



<script src="/assets/js/jquery.flexslider.js"></script>
<script src="/assets/js/async.js"></script>
<script src="/assets/js/moment.js"></script>
<script src="/assets/js/app/user-dashboard.js"></script>

<?php 
  loadLibrary('auth');
?>
<?php if(!$this->auth->is_admin()): ?>
  <script type="text/javascript">
    $(function(){
      $('.build-site-btn').removeClass('hidden');
    })
  </script>
<?php endif;?>


