<section class="top-wrapper bg-blue-dark">
  <header class="header">
    <div class="container">
      <div class="logo">
        <a href="#"><img src="/assets/images/emblm-cmf-logo.png"></a>
      </div>
      <div class="header-right">
        <div class="social-icons text-right">
          <a href="#"><i class="fa fa-facebook-square"></i></a>
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-youtube-play"></i></a>
        </div>
        <nav class="clearfix nav-bar">
          <a href="javascript:;" class="nav-toggle"><em></em><em></em><em></em></a>
          <ul class="navigation">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Features</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
          <ul class="login">

            <li><a href="/user/register" class="btn-success hidden">Register</a></li>
            <li><a href="/user/login" class="bg-blue" id="1login">Login</a>
              <div class="login-box bg-blue" id="login-box">
                <?php echo form_open('/login');?>
                  <label for="">Please Login to proceed</label>
                  <p class="msg hidden text-white"><strong></strong></p> 
                  <div class="form-group">
                    <input type="email" class="form-control" name="username" id="username" placeholder="Email">
                  </div>
                  <div class="form-group">

                    <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                  </div>

                  <button type="submit" class="btn bg-green">Submit</button>
                </form>
              </div>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  </header>
  <div class="container">
    <div class="flexslider">
      <ul class="slides">
        <li class="">
          <img src="/assets/images/banner/banner01.png" />
          <div class="flex-caption">
            <h3>Ready to use website templates customisable as per your needs</h3>
            <div class="btns-group">
              <a href="#" class="btn btn-danger btn-lg">Get Start</a>
              <a href="#" class="btn btn-success btn-lg">Learn More</a>
            </div>
          </div>
        </li>

        <li class="">
          <img src="/assets/images/banner/banner02.png" />
          <div class="flex-caption">
            <h3>Site bulding gets a whole lot simpler </h3>
            <div class="btns-group">
              <a href="#" class="btn btn-danger btn-lg">Get Start</a>
              <a href="#" class="btn btn-success btn-lg">Learn More</a>
            </div>
          </div>
        </li>


      </ul>
    </div>
  </div>
</section>

<section class="features wrapper">
  <div class="container">
    <h2 class="heading1 text-center">Features</h2>

    <div class="feature-captions">
      <span><i class="fa fa-check"></i> From design to deployment </span>
      <span><i class="fa fa-check"></i> Ready to use website templates  </span>
    </div>

    <div class="feature-boxes clearfix">
      <div class="feature-box">
        <a href="#">

          <span class="feature-box-icon">
            <img src="/assets/images/ico1.png">
          </span>
          <span class="feature-box-content">
            <h3>GIGW Compliance </h3>
            <p>Compliant with mandatoryguidelines from the compliance matrix of GIGW</p>
          </span>
        </a>
      </div>

      <div class="feature-box">
        <a href="#">

          <span class="feature-box-icon">
            <img src="/assets/images/ico2.png">
          </span>
          <span class="feature-box-content">
            <h3>Website analytics </h3>
            <p>Provides a dashboard to view visitor</p>
          </span>
        </a>
      </div>

      <div class="feature-box">
        <a href="#">

          <span class="feature-box-icon">
            <img src="/assets/images/ico3.png">
          </span>
          <span class="feature-box-content">
            <h3>Search</h3>
            <p>Integrated search to enable easy discoverability of content</p>
          </span>
        </a>
      </div>

      <div class="feature-box">
        <a href="#">

          <span class="feature-box-icon">
            <img src="/assets/images/ico4.png">
          </span>
          <span class="feature-box-content">
            <h3>Responsive Design</h3>
            <p>Easily accessible through Smart Phones, Tablets and Desktop PC</p>
          </span>
        </a>
      </div>

      <div class="feature-box">
        <a href="#">

          <span class="feature-box-icon">
            <img src="/assets/images/ico5.png">
          </span>
          <span class="feature-box-content">
            <h3>Themes &amp; Templates</h3>
            <p>Easily configurable themes for visually exclusive presentation</p>
          </span>
        </a>
      </div>

      <div class="feature-box">
        <a href="#">

          <span class="feature-box-icon">
            <img src="/assets/images/ico6.png">
          </span>
          <span class="feature-box-content">
            <h3>Translation</h3>
            <p>Using CDAC/Google service</p>
          </span>
        </a>
      </div>
    </div>

  </div>
</section>

<section class="latest-update wrapper bg-red">
  <div class="container">
    <h2 class="heading1 text-center text-white">Latest Updates</h2>

    <ul>
      <li><a href="#">10 steps to building a better government website </a></li>
      <li><a href="#">The government has simplified the planning system so councils have the freedom to make</a></li>
      <li><a href="#">Portal for Digital Government from General Services </a></li>
    </ul>
  </div>
</section>

<section class="themes-wrapper wrapper">
  <div class="container">
    <h2 class="heading1 text-center">Themes</h2>
    <div class="clearfix"><a href="#" class="pull-right text-uppercase hidden">View All </a></div>

    <div class="theme-boxes clearfix">
      <div class="theme-box">
        <div class="theme-thumb">
          <img src="/assets/images/themes/theme3.jpg" alt="">
        </div>
        <div class="hidden  theme-content">
          <h4>Theme Name here...</h4>
          <a href="#" class="btn-preview">Preview <i class="fa fa-eye"></i> </a>
        </div>
      </div>
      <div class="theme-box">
        <div class="theme-thumb">
          <img src="/assets/images/themes/theme2.jpg" alt="">
        </div>
        <div class=" hidden theme-content">
          <h4>Theme Name here...</h4>
          <a href="#" class="btn-preview">Preview <i class="fa fa-eye"></i> </a>
        </div>
      </div>
      <div class="theme-box">
        <div class="theme-thumb">
          <img src="/assets/images/themes/theme3.jpg" alt="">
        </div>
        <div class="hidden  theme-content">
          <h4>Theme Name here...</h4>
          <a href="#" class="btn-preview">Preview <i class="fa fa-eye"></i> </a>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="how-it-works wrapper">
  <div class="container">
    <h2 class="heading1 text-center">How It Works!</h2>

    <div class="video">
      <video width="100%" controls>
        <source src="video.mp4" type="video/mp4">
        <source src="video.ogg" type="video/ogg">
        Your browser does not support HTML5 video.
      </video>
    </div>

    <div class="center-block text-center">
      <a href="#" class="btn btn-lg btn-danger">Frequently Ask Question</a> 
    </div>
  </div>
</section>





<script src="/assets/js/jquery.flexslider.js"></script>
<script src="/assets/js/app/login.js"></script>
