<div class="container">

  <div class="col-md-10 col-md-offset-1 page-login bg-change">
    <h3 class="login-heading text-center">Change Password</h3>
    <?php echo form_open('/user/change-password', array('class' => 'form-horizontal')); ?>
      <div class="form-group">
        <label class="col-sm-3 col-md-3 control-label" for="site_name">Current Password</label>
        <div class="col-sm-9 col-md-9">
          <input type="password" class="form-control" name='current_password' id="current_password" placeholder="Current Passowrd">
          <span class="help-block">
            <span class="default">Your current Password<span class="text-danger">  (mandatory) </span></span>
            <span class='validation hidden'></span>
          </span>
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-3 col-md-3 control-label" for="site_domain">New Password </label>
        <div class="col-sm-9 col-md-9">
          <input type="password" class="form-control" name='new_password' id="new_password" placeholder="New Password">                    
          <span class="help-block">
            <span class="default">New password, minimum length 5 maximum length 12<span class="text-danger">  (mandatory) </span></span>
            <span class='validation hidden'></span>
          </span>
        </div>
      </div>
      <div class="form-group">
        <label class="col-sm-3 col-md-3 control-label" for="site_domain">Confirm new password </label>
        <div class="col-sm-9 col-md-9">
          <input type="password" class="form-control" name='cnf_new_password' id="cnf_new_password" placeholder="Re Enter New Password">                    
          <span class="help-block">
            <span class="default">Re Enter New Password<span class="text-danger">  (mandatory) </span></span>
            <span class='validation hidden'></span>
          </span>
        </div>
      </div>

      <div class="text-center btn-block">
        <button type="reset" class="btn btn-default  btn-lg">Cancel</button>
        <button type="submit" class="btn btn-danger text-white btn-lg">Change Password</button>
      </div>
    </form>
  </div>
  


</div>
<script src="/assets/js/change-password.js"></script>
