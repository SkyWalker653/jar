<section class="top-wrapper bg-blue-dark">
  <header class="header">
    <div class="container">
      <div class="logo">
        <a href="/"><img src="/assets/images/emblm-cmf-logo.png"></a>
      </div>
      <div class="header-right">
        <div class="social-icons text-right">
          <a href="#"><i class="fa fa-facebook-square"></i></a>
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-youtube-play"></i></a>
        </div>
        <nav class="clearfix nav-bar">
          <a href="javascript:;" class="nav-toggle"><em></em><em></em><em></em></a>
          <ul class="navigation">
            <li class="active"><a href="/">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Features</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
          <?php 
            loadLibrary('auth');
          ?>
          <?php if(!$this->auth->is_authenticated()): ?>
          <ul class="login">

            <li><a href="/user/register" class="btn-success">Register</a></li>
            <li><a href="#" class="bg-blue" id="login">Login</a>
              <div class="login-box bg-blue" id="login-box">
                  <?php echo form_open('/login'); ?>
                <label for="">Please Login to proceed</label>
                <div class="form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                </div>
                <div class="form-group">

                  <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                </div>

                <button type="submit" class="btn bg-green">Submit</button>
                </form>
              </div>
            </li>
          </ul>
          <?php else: ?>
            <ul class="navigation pull-right">
              <li><a href="/user/logout">Logout</a></li>
            </ul>               
          <?php endif;?>
        </nav>
      </div>
    </div>
  </header>
</section>