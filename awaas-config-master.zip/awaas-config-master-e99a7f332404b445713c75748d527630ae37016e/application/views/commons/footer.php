<script src="/assets/js/scripts.js"></script>   
<footer class="footer">
  <div class="container">
    <div class="footer-links">
      <ul class="list-inline list-unstyled text-center">
        <li><a href="#">Website Policies </a></li>
        <li><a href="#">Terms of Use</a></li>
        <li><a href="#">Help</a></li>
        <li><a href="#">Contact Us</a></li>
        <li><a href="#">Feedback </a></li>
        <li><a href="#">Visitor's Summary </a></li>
      </ul>
    </div>
    <div class="copyrights">
      <span class="footer-cmf-logo"><img src="/assets/images/cmf-small.png"></span>
      <span class="footer-content">Website Content Managed by <a href="#">NIC</a> , GoI 
        Designed, Developed and Hosted by <a href="#">National Informatics Centre ( NIC )</a></span>
    </div>
  </div>
</footer>

</body>
</html>