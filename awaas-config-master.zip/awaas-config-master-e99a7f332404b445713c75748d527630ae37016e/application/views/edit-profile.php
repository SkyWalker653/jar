<div class="container">
  <?php echo form_open('/user/edit-profile', array('class'=>'form-horizontal')); ?>
    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-primary">       
          <div class="panel-body">
            <legend class="text-center text-primary">Your Details <small>(Used As Technical details)</small></legend>                 
            <div class="form-group">
              <label class="col-sm-3 col-md-2 control-label" for="te_name" >Name</label>
              <div class="col-sm-9 col-md-10">
                <input type="text" class="form-control" id="te_name" name="te_name" placeholder="Enter Applicant Name">
                <span class="help-block">
                  <span class="default">Name can be space separated, no need to add <strong>Mr, Mrs or Miss</strong></span>
                  <span class='validation hidden'></span>
                </span>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 col-md-2 control-label" for="te_email">Email</label>
              <div class="col-sm-9 col-md-10">
                <input type="text" class="form-control" id="te_email" name="te_email" placeholder="Enter Applicant Email">
                <span class="help-block">
                  <span class="default">A valid official mail ID correspondence will be done on mentioned mail ID.</span>
                  <span class='validation hidden'></span>
                </span>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 col-md-2 control-label" for="te_org">Organization</label>
              <div class="col-sm-9 col-md-10">
                <select class="form-control organizations" id="te_org" name="te_org" placeholder="Enter Applicant Organization">
                  <option value="-1">--Select Among Options--</option>                      
                </select>                    
                <span class="help-block">
                  <span class="default">Enter Full name of organization, avoid abbreviations. </span>
                  <span class='validation hidden'></span>
                </span>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 col-md-2 control-label" for="te_name">Address</label>
              <div class="col-sm-9 col-md-10">
                <input type="text" class="form-control" id="te_addr" name="te_addr" placeholder="Enter Applicant Address">
                <span class="help-block">
                  <span class="default">Full Address of Applicant</span>
                  <span class='validation hidden'></span>
                </span>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 col-md-2 control-label" for="te_state">State</label>
              <div class="col-sm-9 col-md-10">
                <input type="text" class="form-control" id="te_state" name="te_state" placeholder="Enter Applicant State">
                <span class="help-block">                      
                  <span class='validation hidden'></span>
                </span>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 col-md-2 control-label" for="te_pincode">Pincode</label>
              <div class="col-sm-9 col-md-10">
                <input type="text" class="form-control" id="te_pincode" name="te_pincode" placeholder="Enter Applicant Address Pincode">
                <span class="help-block">
                  <span class="default">Pincode should be 6 digit number of your locality.</span>
                  <span class='validation hidden'></span>
                </span>
              </div>
            </div>                
            <div class="form-group">
              <label class="col-sm-3 col-md-2 control-label" for="te_name">Telephone</label>
              <div class="col-sm-9 col-md-10">
                <input type="text" class="form-control" id="te_telephone" name="te_telephone" placeholder="Enter Applicant Telephone Number">
                <span class="help-block">
                  <span class="default">Landline Number, Add STD code as prefix!</span>
                  <span class='validation hidden'></span>
                </span>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 col-md-2 control-label" for="te_mobile">Mobile</label>
              <div class="col-sm-9 col-md-10">
                <input type="text" class="form-control" id="te_mobile" name="te_mobile" placeholder="Enter Applicant's mobile Number">
                <span class="help-block">
                  <span class="default">Valid Mobile number, No need to prefix <strong>+91</strong> or <strong>0</strong></span>
                  <span class='validation hidden'></span>
                </span>
              </div>
            </div>                        
          </div>
          <div class="panel-footer">
            <div class="row">            
              <div class="col-md-2 col-md-offset-5 ">
                <button type='submit' class=" btn btn-primary pull-right">Update Details</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>  
  </form>
</div>
<script src="/assets/js/async.js"></script>
<script src="/assets/js/moment.js"></script>
<script src="/assets/js/select2.js"></script>
<link rel="stylesheet" type="text/css" href="/assets/css/select2.css">

<script type="text/javascript">
  (function(){
    var default_technical_user = [];
    var organizations = [];
    function getData(url, cb) {
      $.ajax({
        "url": url,
        "method": 'GET',
        "success": function (data) {
          cb(null, data);
        },
        "error": function (err, text_status, status_msg) {
          cb('status_msg', null);
        }
      });
    };

    function loadMasterData() {
      async.parallel(
      {       
        organizations: function(callback){
          getData('/master/organizations', function (err, data) {
            if (err) {
              return callback(err, data);
            }
            return callback(err, data);
          });
        },
        default_technical_user: function(callback){
          getData('/master/default-technical-details', function (err, data) {
            if (err) {
              return callback(err, data);
            }
            return callback(err, data);
          });
        } 
      },
      function (err, results) {
        if (err) {
          return alert('something went wrong!!');
        }

        organizations = results['organizations'];
        default_technical_user = results['default_technical_user'];        
        popluateOrganizations();
        populateTechnicalDetails();
      });
    }

    function popluateOrganizations(){
      org_master_data = organizations;

      org_master_data = org_master_data.reduce(function(pv, cv){
        pv[cv['id']] = cv;   
        return pv;   
      },[]);

      organizations = organizations.map(function(org){
        return '<option value="'+org['id']+'">'+org['orgn_name']+'</option>';      
      });

      // appending it to drop down and initializing select 2
      $('.organizations').append(organizations.join('')).select2({
        placeholder: "Select Your Organization",
        allowClear: true
      });

      // adding listner for the same
      $('.organizations').on('change', function(){
        var org = $(this).val();
        var that = this;
        getData('/organization/hierarchy/'+org, function (err, data) {
          var html = [];
          if(err){
            alert('Something went wrong');
            return
          }
          if(data && data.length){


            // sort data 
            data.sort(function(a, b){
              return a['path_length'] - b['path_length'];
            });

            for (var i = data.length - 1; i >= 0; i--) {
              html.push('<strong>' +org_master_data[data[i]['parent_id']]['orgn_name'] + '</strong>');
            }
          }
          var control = $(that).parents('.form-group ').find('.help-block .default').html(html.join(' >> '));
        });
      });

      $('.select2').css('width', '100%');
    }

    function populateTechnicalDetails(){
      if(!default_technical_user){
        return;
      }
      $.each(default_technical_user, function(key, value) {
        // fix for organization
        key = key=='organization'? 'org':key;
        key = key=='address'? 'addr':key;
        // seting value
        $('[name=te_'+key+']').val(value).trigger('change');
        if(key == 'email'){
          $('[name=te_'+key+']').attr('readonly', true);
        }
      });    
    }

    function updateDetails() {
      clearFarmErrors();
      $.ajax({
        "method": 'POST',
        "success": function (response) {
          debugger;
          if (response.redirect) {
            window.location.href = response.redirect;
          } 
        },
        "error": function (err, text_status, status_msg) {
          if (status_msg == 'Invalid data' && err.responseJSON) {
            showFormErrors(err.responseJSON);
          }
        },
        "data": $(this).serialize()

      });
    };

    function showFormErrors(err) {

      Object.keys(err).forEach(function (field) {
        showFieldError($('[name=' + field + ']'), err[field]);
      });
    };

    function showFieldError(selector, msg) {
      if(selector.attr('type') == 'hidden'){
        return alert(msg);      
      }

      var control = selector.parents('.form-group ').addClass('has-error');
      control.find('.help-block .default').addClass('hidden');
      control.find('.help-block .validation').removeClass('hidden').text(msg);

      control.find(':input').one('focus', function () {
        hideFieldError(selector);
      });
    }

    function hideFieldError(selector) {
      var control = selector.parents('.form-group ').removeClass('has-error');
      control.find('.help-block .default').removeClass('hidden');
      control.find('.help-block .validation').addClass('hidden').text('');
    }

    function clearFarmErrors() {
      $('form').find(':input').each(function (index, el) {
        hideFieldError($(el));
      });
    }

    $(function(){
      loadMasterData();
      $('form').submit(function (e) {
        e.preventDefault();
        updateDetails.call(this);
      });
    })


  })();
</script>