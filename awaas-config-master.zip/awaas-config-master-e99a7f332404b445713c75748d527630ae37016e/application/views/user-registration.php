<section>
  <div class="container">
    <h1 class="heading2">Please fill the from below to start the service</h1>
  </div>

  <div class="container">
    <div class="registration">
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 page-content-left">

        <?php echo form_open('user/register', array('class' => 'form-horizontal')); ?>
        <div class="form-group">         
          <input type="text" class="form-control" autocomplete="off" name='site_url' id="site_url" placeholder="Web Site URL">
          <span class="help-block">
            <span class="default">A valid Web Site URL<span class="text-danger">  (mandatory) </span></span>
            <span class='validation hidden'></span>
          </span>
        </div>
        <div class="form-group">         
          <input type="text" class="form-control" autocomplete="off" name='user_email' id="user_email" placeholder="Your Official E-mail ID">
          <span class="help-block">
            <span class="default">Official Email ID<span class="text-danger">  (mandatory) </span></span>
            <span class='validation hidden'></span>
          </span>
        </div>
        <div class="form-group">         
          <input type="password" class="form-control" autocomplete="off" name='user_password' id="user_password" placeholder="User Password">
          <span class="help-block">
            <span class="default">User Password minimum length 5, should not exceed 12<span class="text-danger">  (mandatory) </span></span>
            <span class='validation hidden'></span>
          </span>
        </div>
        
       

        <div class="form-group">
          <label class="radio-inline">
            <input type="radio" name="min_dept_apex" id="inlineRadio1" value="apex"> Apex
          </label>
          <label class="radio-inline">
            <input type="radio" name="min_dept_apex" id="inlineRadio2" value="min"> Ministry
          </label>
          <label class="radio-inline">
            <input type="radio" name="min_dept_apex" id="inlineRadio3" value="dept"> Department
          </label>
          <span class="help-block">
            <span class="default">Choose appropriate Option! <span class="text-danger">  (mandatory) </span></span>
            <span class='validation hidden'></span>
          </span>
        </div>

        <div class="form-group">
          <select class="form-control" name='min' id="ministry">
            <option>Choose Ministry Name</option>
            <option>Ministry 2</option>
            <option>Ministry 3</option>
            <option>Ministry 4</option>
          </select>
          <span class="help-block">
            <span class="default">Select Your ministry! <span class="text-danger">  (mandatory) </span></span>
            <span class='validation hidden'></span>
          </span>
        </div> 
        
        <div class="form-group">         
          <textarea class="form-control" autocomplete="off" name='user_comment' id="user_comment" placeholder="Location State/ District"></textarea>
          <span class="help-block">
            <span class="default">Describe About Locality! <span class="text-info">  (optional) </span></span>
            <span class='validation hidden'></span>
          </span>
        </div>

        

        <button type="submit" class="btn btn-default bg-blue text-white btn-lg" >Submit</button>
        </form>


      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 page-content-right">
        <div class="inner-content"><h3>How to Use?</h3>
          <h5>Step 1</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed quam metus. Fusce sed urna erat. Maecenas a volutpat lacus, in facilisis elit. Fusce</p>
          <h5>Step 2</h5>
          <p>Nisl at dolor tempus placerat vel sed massa. Aliquam mattis at neque ac consectetur. </p>
          <h5>Step 3</h5>
          <p>Fusce imperdiet orci a velit euismod elementum. Cras id elit ut ipsum pharetra </p>
          <h5>Step 4</h5>
          <p>congue eleifend quis lorem. Fusce a cursus leo. Pellentesque commodo magna volutpat, placerat turpis in </p>
          <h5>Step 5</h5>
          <p>Auctor tellus. Pellentesque porta risus sit amet  </p></div>
      </div>
    </div>
  </div>
</section>
