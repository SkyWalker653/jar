<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Organizations_model extends CI_Model {

  public function __construct() {
    parent::__construct();
    $this->load->database();
  }

  public function get_organizations($where, $single=FALSE) {
    $query = $this->db->where($where)->get('orgs');
    if($single){
      return $query->row_array();    
    }
    return $query->result_array();    
  }

  public function get_hierarchy($where, $single=FALSE) {
    $query = $this->db->where($where)->get('orgs_hierarchy');
    if($single){
      return $query->row_array();    
    }
    return $query->result_array();    
  }

}
