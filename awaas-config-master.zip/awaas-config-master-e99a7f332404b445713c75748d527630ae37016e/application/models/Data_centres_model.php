<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Data_centres_model extends CI_Model {

  public function __construct() {
    parent::__construct();
    $this->load->database();
  }

  public function get_data_centrers($where, $single=FALSE) {
    $query = $this->db->where($where)->get('data_centres');
    if($single){
      return $query->row_array();    
    }
    return $query->result_array();    
  }

  

}
