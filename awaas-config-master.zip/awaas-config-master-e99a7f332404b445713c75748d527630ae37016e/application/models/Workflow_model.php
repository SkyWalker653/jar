<?php

class Workflow_model extends CI_Model {

  public function __construct() {
    parent::__construct();
    $this->load->database();
  }
  
  public function get_workflow_stages() {
    $query = $this->db->get('work_flow_stages');
    return $query->result_array();
    
  }
  
  public function get_workflow($where) {    
    $query = $this->db->where($where)->get('work_flow');
    return $query->result_array();    
  }
  
  

  public function get_possible_stages($current_stage, $role) {
    $query = $this->db->where(array('current_stage' => $current_stage, 'role' => $role))->get('work_flow');
    return $query->row_array();
  }

  public function update_stage($site_id, $requested_stage) {
    $data = array(
      'workflow_stage' => $requested_stage,      
    );

    $res = $this->db->where(array('id'=>$site_id))->update('sites', $data);
    return $this->_build_insert_response($res);
  }
  
  private function _build_insert_response($res) {
    if ($res) {
      return array('status' => $res, 'id' => $this->db->insert_id());
    }
    return array('status' => $res, 'error' => $this->db->error());
  }

}
