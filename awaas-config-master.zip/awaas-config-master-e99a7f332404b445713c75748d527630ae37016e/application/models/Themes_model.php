<?php

class Themes_model extends CI_Model {

  public function get_themes($where = array(), $single = FALSE) {
    $query = $this->db->where($where)->get('themes');
    if ($single) {
      return $query->row_array();
    }
    return $query->result_array();
  }

}
