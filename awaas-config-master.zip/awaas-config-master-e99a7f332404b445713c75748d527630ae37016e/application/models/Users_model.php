<?php

class Users_model extends CI_Model {

  public function __construct() {
    parent::__construct();
    $this->load->database();
  }

  public function authenticate() {
    $query = $this->db->where(array('username' => $this->input->post('username'), 'password' => $this->input->post('password')))->get('app_users');
//    return $query->row(0, 'array');
    return $query->row_array();
  }

  public function get_users($where, $single = FALSE) {    
    $query = $this->db->where($where)->get('app_users');
    if ($single) {
      return $query->row_array();
    }
    return $query->result_array();
  }

  public function update_user($data, $where) {
    $this->db->where($where);
    $this->db->update('app_users', $data);
  }

  public function create_user($data) {
    $res = $this->db->insert('app_users', $data);
    return $this->db->insert_id();    
  }
  
}
