<?php

class Sites_model extends CI_Model {

  public function __construct() {
    parent::__construct();
    $this->load->database();
  }
  
  public function get_sites($where, $single=FALSE){
    $query = $this->db->where($where)->get('sites');
    if($single){
      return $query->row_array();    
    }
    return $query->result_array();    
  }
  
  public function get_site_users($where, $single=FALSE){
    $query = $this->db->where($where)->get('site_users');
    if($single){
      return $query->row_array();    
    }
    return $query->result_array();    
  }
  
  public function get_sites_site_users_mapping($where){
    $query = $this->db->where($where)->get('sites_site_users_mapping');
    return $query->result_array();
  }

  public function create_site($data) {
    $res = $this->db->insert('sites', $data);
    return $this->_build_insert_response($res);
  }

  public function create_site_user($user) {
    $res = $this->db->insert('site_users', $user);
    return $this->_build_insert_response($res);
  }
  
  public function map_sites_site_users($mapping){
    $res = $this->db->insert_batch('sites_site_users_mapping', $mapping);
    return $res;
  }
  
  public function update($where, $data){
    $res = $this->db->where($where)->update('sites', $data);
    return $this->_build_insert_response($res);
  }

  public function update_site_user($where, $data){
    $res = $this->db->where($where)->update('site_users', $data);    
  }

  private function _build_insert_response($res) {
    if ($res) {
      return array('status' => $res, 'id' => $this->db->insert_id());
    }
    return array('status' => $res, 'error' => $this->db->error());
  }

}
