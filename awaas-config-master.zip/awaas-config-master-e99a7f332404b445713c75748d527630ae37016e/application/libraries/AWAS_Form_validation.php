<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class AWAS_Form_validation extends CI_Form_validation {
  protected $org_config_rules	= array();

  public function __construct($config = array()) {
    parent::__construct($config);    
    $this->org_config_rules = $this->_config_rules;
	
	$this->CI->load->library('validation');
  }
  
  public function validate_website_registration_form(){    
    if($this->run('max_registration_steps') == FALSE){      
      return FALSE;
    }
//    resetting data
    $this->_field_data = array();
    $current_step = $this->CI->input->post('step');
    
//    validate only the step which are already passed
    $this->_config_rules['website_registration'] = array();
    for ($i = $current_step; $i >= 0; $i--) {
      $this->_config_rules['website_registration'] = array_merge ($this->_config_rules['website_registration'], $this->org_config_rules['website_registration'][''.$i]);
    }    
    
    return $this->run('website_registration');
  }
  
  public function validate_login_form(){
    return $this->run('login');
  }

  public function validate_user_details(){
    $this->_field_data = array();
    $this->_config_rules['user_details'] = array();
    $this->_config_rules['user_details'] = array_merge ($this->_config_rules['user_details'], $this->org_config_rules['website_registration']['2']);
    return $this->run('user_details');

  }
  
  public function is_valid_text($str) {
		
        $this->CI->form_validation->set_message('is_valid_text', 'The %s contains invalid characters.');

	   if($this->CI->validation->isValidText($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
   }
   
   
   public function is_safe_text($str) {
		
        $this->CI->form_validation->set_message('is_safe_text', 'The %s contains invalid characters.');

	   if($this->CI->validation->isSafeText($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
   }
   
   
  public function is_address($str) {
		
        $this->CI->form_validation->set_message('is_address', 'The %s contains invalid characters.');

	   if($this->CI->validation->isAddress($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
   }
   
   
   public function is_alpha_space($str) {
		
	   $this->CI->form_validation->set_message('is_alpha_space', 'The %s may only contain alphabetic characters & spaces');
	   
	   if($this->CI->validation->isAlphabeticWhiteSpace($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
     
    }
	
	/**
     * AWAS_Form_validation::alpha_extra().
     * Alpha-numeric with periods, underscores, spaces and dashes.
     */
    public function is_alpha_extra($str) {
		
	   $this->CI->form_validation->set_message('is_alpha_extra', 'The %s may only contain alpha-numeric characters, spaces, periods, underscores & dashes.');
	   
	   if($this->CI->validation->isAlphaExtra($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
     
    }
	
	
	
	
	public function is_alpha_numeric($str) {
		
	   $this->CI->form_validation->set_message('is_alpha_numeric', 'The %s may only contain alpha-numeric characters.');
	   
	   if($this->CI->validation->isAlphaNumeric($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
     
    }
	
	
	public function is_valid_name($str) {
		
        $this->CI->form_validation->set_message('is_valid_name', 'The %s may only contain alphabetic, spaces & periods.');
		
		
	   if($this->CI->validation->isValidName($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	
	public function is_valid_email($str) {
		
		$str=$this->CI->validation->decodeEmail($str); // [at] => @, [dot] => .
		
        $this->CI->form_validation->set_message('is_valid_email', 'Please enter a valid %s.');
		
		
	   if($this->CI->validation->isEmail($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	public function is_valid_mobile($str) {
		
        $this->CI->form_validation->set_message('is_valid_mobile', 'Please enter a valid %s.');
		
		
	   if($this->CI->validation->isMobileTenDigits($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	
	public function is_mobile_ten_digits($str) {
		
        $this->CI->form_validation->set_message('is_mobile_ten_digits', 'Please enter ten digits %s.');
		
		
	   if($this->CI->validation->isMobileTenDigits($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	
	
	public function is_valid_pincode($str) {
		
        $this->CI->form_validation->set_message('is_valid_pincode', 'Please enter valid %s.');
		
		
	   if($this->CI->validation->isValidPinCode($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	
	
	public function is_valid_stdcode($str) {
		
        $this->CI->form_validation->set_message('is_valid_stdcode', 'Please enter valid %s.');
		
		
	   if($this->CI->validation->isValidStdCode($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	
		
	public function is_valid_phone($str) {
		
        $this->CI->form_validation->set_message('is_valid_phone', 'Please enter valid %s.');
		
		
	   if($this->CI->validation->isValidPhoneWithSTD($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	
	
	
	
	public function is_valid_fax($str) {
		
        $this->CI->form_validation->set_message('is_valid_fax', 'Please enter a valid %s.');
		
		
	   if($this->CI->validation->isValidPhone3($str)) // fax is same as phone number
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	
	public function is_valid_md5($str) {
		
        $this->CI->form_validation->set_message('is_valid_md5', 'Please enter valid %s.');
		
		
	   if($this->CI->validation->isValidMd5($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	
	
	public function is_url($str) {
		
        $this->CI->form_validation->set_message('is_url', 'Please enter valid %s.');

	   if($this->CI->validation->isURL($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	
	public function is_integer($str) {
		
        $this->CI->form_validation->set_message('is_integer', 'Please enter valid %s.');

	   if($this->CI->validation->isInteger($str))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
	  
    }
	
	public function is_yes_no($str) {
		
	   $this->CI->form_validation->set_message('is_yes_no', 'Please enter valid %s.');
	   
	   if($this->CI->validation->is_listed_value($str, array('yes','no')))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
     
    }
	

	public function is_zero_one($str) {
		
	   $this->CI->form_validation->set_message('is_zero_one', 'Please enter/select valid %s.');
	   
	   if($this->CI->validation->is_listed_value($str, array('0','1')))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
     
    }
	
	public function is_valid_role($str) {
		
	   $this->CI->form_validation->set_message('is_valid_role', 'Please enter valid %s.');
	   
	   if($this->CI->validation->is_listed_value($str, array('jury')))
	   {
		   return TRUE;
	   }
	   else
	   {
		   return FALSE;
	   }  
     
    }
}
