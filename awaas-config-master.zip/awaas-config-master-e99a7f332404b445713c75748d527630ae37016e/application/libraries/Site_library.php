<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Site
 *
 * @author sid
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Site_library {

  protected $CI;

  public function __construct() {
    $this->CI = & get_instance();
    $this->CI->load->model('sites_model');
    $this->CI->load->model('themes_model');
    $this->CI->load->model('users_model');
    $this->CI->load->model('organizations_model');
    $this->CI->load->model('data_centres_model');
    $this->CI->load->library('auth');
    $this->CI->load->library('organization_library');
    $this->CI->load->helper('date');
  }
  
  public function get_site($site_id, $expanded = FALSE){
    $site = $this->CI->sites_model->get_sites(array('id'=> $site_id), TRUE);
    if(!$expanded){
      return $site;
    }
    
//    getting site users
    $site_users = $this->CI->sites_model->get_sites_site_users_mapping(array('site_id'=> $site_id));
    foreach ($site_users as $key => $site_user) {
      $site[$site_user['site_user_type']] = $this->CI->sites_model->get_site_users(array('id'=>$site_user['site_user_id']), TRUE);            
      $site[$site_user['site_user_type']]['organization'] = $this->CI->organization_library->get_organization_hierarchy_by_org_id($site[$site_user['site_user_type']]['organization']);      
    }
    
    $site['data_centre'] = $this->CI->data_centres_model->get_data_centrers(array('id'=>$site['data_centre']),TRUE);
    $site['theme'] = $this->CI->themes_model->get_themes(array('id'=>$site['theme']),TRUE);
    $site['creator'] = $this->CI->users_model->get_users(array('id'=>$site['creator']),TRUE);

    return $site;
  }

  public function register_site() {
//    Extract site data
    $data = array(
      'site_details' => $this->get_website_details(),      
      'technical_details' => $this->get_technical_details(),
      'owner_details' => $this->get_owner_details(),
    );


    
//    requesting cluster to make instance
    $site_creation_response = $this->request_to_make_instance($data);
    if($site_creation_response['isSuccess'] != TRUE){
      $resp = array('isSuccess' => FALSE, 'msg' =>$site_creation_response['data']['message']);
      return $resp;
    }
    $data['site_details']['staging_url'] = $site_creation_response['data']['url'];
    $data['site_details']['customized_url'] = $site_creation_response['data']['customized_url'];
    

//    save data to database
    $data['site_details']['_insert_status'] = $this->CI->sites_model->create_site($data['site_details']);
    
    $user = $this->CI->auth->loggedin_user();    
    $associated_site_user = $this->CI->sites_model->get_site_users(array('id'=>$user['associated_site_user']), TRUE);
    if(empty($associated_site_user)){
//      update associated profile here
      $data['technical_details']['_insert_status'] = $this->CI->sites_model->create_site_user($data['technical_details']);
      $this->CI->users_model->update_user(array('associated_site_user'=>$data['technical_details']['_insert_status']['id']), array('id'=>$user['id']));
    }else{
      $data['technical_details']['_insert_status'] = array('id'=>  $associated_site_user['id']);
    }
    
    $data['owner_details']['_insert_status'] = $this->CI->sites_model->create_site_user($data['owner_details']);
    

//    mapping users with site
    $mapping = array();
    
    $mapping[] = array(
      'site_id' => $data['site_details']['_insert_status']['id'], 
      'site_user_id' => $data['technical_details']['_insert_status']['id'],
      'site_user_type'=>'technical'
    );
    $mapping[] = array(
      'site_id' => $data['site_details']['_insert_status']['id'], 
      'site_user_id' => $data['owner_details']['_insert_status']['id'],
      'site_user_type'=>'owner'
    );
    $this->CI->sites_model->map_sites_site_users($mapping); 
    $data['isSuccess'] = TRUE;
    
    return $data;
  }

  public function get_users_sites(){
//    get loggedin user's role
    if($this->CI->auth->is_admin()){
      return $this->CI->sites_model->get_sites(array(''));
    }else if($this->CI->auth->is_user()){
      $user_id = $this->CI->auth->user_id();
      return $this->CI->sites_model->get_sites(array('creator' => $user_id));
    }
    return NULL;            
  }
  
  public function update_site() {
    
  }

  private function request_to_make_instance($site_data){
    $theme_id = $site_data['site_details']['theme'];
    $title = $site_data['site_details']['name'];
    $email = $site_data['technical_details']['email'];
//    getting datacentre details and fetching url
    $ds = $site_data['site_details']['data_centre'];
    $ds = $this->CI->data_centres_model->get_data_centrers(array('id'=>$ds),TRUE);
    $saas_url = $ds['cluster_url'];

    $postdata = http_build_query(
      array(
        'template_id' => $theme_id,
        'title' => $title,
        'email' => $email       
      )
    );

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $saas_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,$postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
//    parsing output
    $server_output = curl_exec ($ch);
    $response = json_decode($server_output, TRUE);
    return $response;    
  }

  private function get_website_details() {
    return array(
      'name' => $this->CI->input->post('site_name'),
      'url' => $this->CI->input->post('site_domain'),
      'data_centre' => $this->CI->input->post('site_dc'),
      'workflow_stage'=>1,
      'creator'=>$this->CI->auth->user_id(),
      'theme'=>$this->CI->input->post('template'),
      'created'=>now(),
      'last_updated'=>now()
    );
  }

  public function get_technical_details() {
    return $this->get_user_details('te_');
  }

  private function get_owner_details() {
    return $this->get_user_details('owner_');
  }

  private function get_user_details($prefix = '') {
    $vars = array(
      'name' => 'name',
      'org' => 'organization',
      'addr' => 'address',
      'state' => 'state',
      'pincode' => 'pincode',
      'email' => 'email',
      'telephone' => 'telephone',
      'mobile' => 'mobile'
    );
    $data = array();
    foreach ($vars as $key => $db_name) {
      $data[$db_name] = $this->CI->input->post($prefix . $key);
    }
    return $data;
  }

}
