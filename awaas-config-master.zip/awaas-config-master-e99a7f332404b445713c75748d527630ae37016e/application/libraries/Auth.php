<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Auth {

  protected $CI;

  public function __construct() {
    $this->CI = & get_instance();
    $this->CI->load->library('session');
    $this->CI->load->helper('oauth');
    $this->CI->load->model('users_model');
    $this->CI->load->model('sites_model');
    $this->CI->load->library('form_validation');
  }
  
  public function change_password($new_password){
    $user = $this->loggedin_user();
    $this->CI->users_model->update_user(array('password'=>$new_password), array('id'=> $user['id']));    
  }
  
  public function is_valid_current_password($password){
    $user = $this->loggedin_user();
    return ($user['password']== $password);    
  }

  public function is_authenticated() {
    return $this->CI->session->has_userdata('authenticated') && $this->CI->session->userdata('authenticated');
  }

  public function is_admin() {
    $id = $this->user_id();
    $user = $this->CI->users_model->get_users(array('id' => $id), TRUE);
    if ($user['role'] && $user['role'] == 'admin') {
      return TRUE;
    } else {
      return FALSE;
    }
  }
  
  public function user_role(){
    $this->CI->session->has_userdata('id') && $id =  $this->CI->session->userdata('id');
    if (!isset($id) || !is_numeric($id)) {
      return FALSE;
    }
    $user = $this->CI->users_model->get_users(array('id' => $id), TRUE);
    return $user['role'] ;
  }

  public function is_user() {
    $this->CI->session->has_userdata('id') && $id = $this->CI->session->userdata('id');
    if (!isset($id) || !is_numeric($id)) {
      return FALSE;
    }
    $user = $this->CI->users_model->get_users(array('id' => $id), TRUE);
    if ($user['role'] && $user['role'] == 'user') {
      return TRUE;
    } else {
      return FALSE;
    }
  }

  public function is_owner_of_site($site_id) {
    $user_id = $this->user_id();
    
    $site = $this->CI->sites_model->get_sites(array('creator'=>$user_id, 'id'=>$site_id), TRUE);
    
    if(empty($site)){
      return FALSE;
    }
    return TRUE;
  }

  public function authenticate_user() {
//    validate login form info
    if ($this->CI->form_validation->validate_login_form()) {
//      validate user info
      $user = $this->CI->users_model->authenticate();
      if (is_null($user)) {
        return FALSE;
      }
      $this->CI->session->set_userdata(array('authenticated' => TRUE, 'id' => $user['id']));
      return TRUE;
    } else {
      return FALSE;
    }
  }

  public function authenticate_user1() {
//    validate login form info
    if ($this->CI->form_validation->validate_login_form()) {
//      validate user info
      $user = $this->CI->users_model->authenticate();
      if (is_null($user)) {
        return FALSE;
      }
      $this->CI->session->set_userdata(array('authenticated' => TRUE, 'id' => $user['id']));
      return TRUE;
    } else {
      return FALSE;
    }
  }

  public function logout_user() {
    $this->CI->session->unset_userdata(array('authenticated', 'id'));
  }
  
  public function user_id(){
    $this->CI->session->has_userdata('id') && $id = $this->CI->session->userdata('id');
    if (!isset($id) || !is_numeric($id)) {
      return FALSE;
    }
    return $id;
  }

  public function loggedin_user() {
    $id = $this->CI->session->has_userdata('id') ? $this->CI->session->userdata('id'):FALSE;
    if (!is_numeric($id)) {
      return FALSE;
    }
    $user = $this->CI->users_model->get_users(array('id' => $id), TRUE);
    return $user;
  }

}
