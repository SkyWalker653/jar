<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pdf_generator {

  protected $CI;

  public function __construct() {
    $this->CI = & get_instance();   
    $this->CI->load->helper('string');
    $this->CI->load->helper('file');
    
  }
  
  public function genrateAuthLetter($site){
    $html_string = read_file(APPPATH.'/pdf_assets/auth_letter_template.html');
//    replace template with data
    $html_string = str_replace('{{text_here}}', json_encode($site), $html_string);
    $html_file_path = APPPATH.'/tmp/'.random_string().'.html';
    write_file($html_file_path, $html_string);
    return $this->generatePdf($html_file_path);    
  }
  
  public function generatePdf($html_file_path){
    $bin = $this->CI->config->item('phantom_path').'/bin/phantomjs';
    $op_file_name = random_string().'.pdf';
    $op_file_path = APPPATH.'/'.$this->CI->config->item('generated_auth_letters_path').'/'.$op_file_name;
    $phantom_file = APPPATH.'/pdf_assets/phantom_exporter.js';    
    exec($bin.' ' . $phantom_file. ' ' . $op_file_path .' '.$html_file_path . ' ' . $this->CI->config->item('base_url'));
    return $op_file_name;
  }

  

}
