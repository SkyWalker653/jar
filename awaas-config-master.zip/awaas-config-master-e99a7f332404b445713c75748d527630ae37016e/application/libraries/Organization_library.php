<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Site
 *
 * @author sid
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Organization_library {

  protected $CI;

  public function __construct() {
    $this->CI = & get_instance();
    $this->CI->load->model('organizations_model');
  }

  public function get_organization_hierarchy($org){
    $hierarchy = $this->CI->organizations_model->get_hierarchy(array('id'=>$org['id']));
    foreach ($hierarchy as &$value) {
      $value['parent_details'] = $this->CI->organizations_model->get_organizations(array('id'=>$value['parent_id']), TRUE);
    }

    $org['hierarchy']= $hierarchy;
    return $org;
  }

  public function get_organization_hierarchy_by_org_id($org_id){
    $organization = $this->CI->organizations_model->get_organizations(array('id'=>$org_id), TRUE);
    return $this->get_organization_hierarchy($organization);
  } 
  
}
