<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Workflow {

  protected $CI;

  public function __construct() {
    $this->CI = & get_instance();
    $this->CI->load->library('auth');
    $this->CI->load->model('workflow_model');
    $this->CI->load->library('site_library', NULL, 'site');
    $this->CI->load->library('pdf_generator');
    $this->CI->load->helper('file');
  }

  public function is_valid_next_stage($current_stage, $requested_stage) {
    $possible_stages = $this->get_possible_stages($current_stage);
    $ret = array_search($requested_stage, $possible_stages);
    if (is_numeric($ret)) {
      return TRUE;
    }
    return FALSE;
  }

  public function get_possible_stages($current_stage) {
    $role = $this->CI->auth->user_role();
    $possible_stages = $this->CI->workflow_model->get_possible_stages($current_stage, $role);
    return explode(",", $possible_stages['possible_stages']);
  }

  public function move($site_id, $current_stage, $requested_stage) {
//    log here about this movement
//    checking what is the current stage and do the need ful
    $case_res = array(
      "content_type"=>json_encode(array('success'=>TRUE)),
      "content"=>'application/json'
    );
    switch ($requested_stage) {
      case 2:
//        user requested to generate auth letter
        $site = $this->CI->site->get_site($site_id, TRUE);
        $auth_letter_name = $this->CI->pdf_generator->genrateAuthLetter($site);
        $this->CI->sites_model->update(array('id' => $site_id), array('generated_auth_letter_name' => $auth_letter_name, 'scanned_auth_letter_name' => ''));
        break;

      case 3:
//      we will be sening auth letter for donwload
        $site = $this->CI->site->get_site($site_id);
        if(empty($site['scanned_auth_letter_name'])){
          $auth_letter_location = $this->CI->config->item('generated_auth_letters_path').'/'.$site['generated_auth_letter_name'];
        }else{
          $auth_letter_location = $this->CI->config->item('scanned_auth_letters_path').'/'.$site['scanned_auth_letter_name'];
        }
        $case_res = array(
          'content_type' => get_mime_by_extension($site['generated_auth_letter_name']),
          'content' => file_get_contents(APPPATH.'/'.$auth_letter_location),
          'header' => 'Content-Disposition: attachment;filename='.$site['name'].'_authletter.pdf'
        );
        break;
        
      case 6:
        //user is expected to come with additional upload auth letter field
        //get it and act on it
        $this->CI->load->library('upload');
        if (!$this->CI->upload->do_upload('auth_letter')) {
          $error = array('error' => $this->CI->upload->display_errors());
          return $error;
        } else {
          $data = array('uploaded_data' => $this->CI->upload->data());
          $this->CI->sites_model->update(array('id' => $site_id), array('scanned_auth_letter_name' => $data['uploaded_data']['file_name']));
        }
        break;

      default:
        break;
    }


//   making it impotent 
    $res = $this->CI->workflow_model->update_stage($site_id, $requested_stage);

    $res = array_merge($res, $case_res);
    return $res;
  }

}
