<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Master extends CI_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->library('auth');
    $this->load->model('workflow_model');
    $this->load->model('themes_model');
    $this->load->model('data_centres_model');
    $this->load->model('organizations_model');
    $this->load->model('sites_model');
  }

  public function workflow() {
    if (!$this->auth->is_authenticated()) {
      redirect('/');
    }

    if ($this->input->server('REQUEST_METHOD') == 'GET' && $this->input->is_ajax_request()) {
      return $this->output->set_status_header(200)->set_output(json_encode($this->workflow_model-> get_workflow(array('role' => $this->auth->user_role()))))->set_content_type('application/json');
    }
    show_404();
  }

  public function workflow_stages() {
    if (!$this->auth->is_authenticated()) {
      redirect('/');
    }

    if ($this->input->server('REQUEST_METHOD') == 'GET' && $this->input->is_ajax_request()) {
      return $this->output->set_status_header(200)->set_output(json_encode($this->workflow_model-> get_workflow_stages()))->set_content_type('application/json');
    }
    show_404();
  }
  
  public function themes() {
    if (!$this->auth->is_authenticated()) {
      redirect('/');
    }

    if ($this->input->server('REQUEST_METHOD') == 'GET' && $this->input->is_ajax_request()) {
      return $this->output->set_status_header(200)->set_output(json_encode($this->themes_model-> get_themes()))->set_content_type('application/json');
    }
    show_404();
  }

  public function datacentres() {
    if (!$this->auth->is_authenticated()) {
      redirect('/');
    }

    if ($this->input->server('REQUEST_METHOD') == 'GET' && $this->input->is_ajax_request()) {
      return $this->output->set_status_header(200)->set_output(json_encode($this->data_centres_model->get_data_centrers(array())))->set_content_type('application/json');
    }
    show_404();
  }

  public function organizations() {
    if (!$this->auth->is_authenticated()) {
      redirect('/');
    }

    if ($this->input->server('REQUEST_METHOD') == 'GET' && $this->input->is_ajax_request()) {
      return $this->output->set_status_header(200)->set_output(json_encode($this->organizations_model->get_organizations(array())))->set_content_type('application/json');
    }
    show_404();
  }

  public function default_technical_details(){
    if (!$this->auth->is_authenticated()) {
      return $this->output->set_status_header(401);
    }
    $user = $this->auth->loggedin_user();    
    // getting site user associated with account
    $associated_site_user = $this->sites_model->get_site_users(array('id'=>$user['associated_site_user']), TRUE);
    if(empty($associated_site_user)){
      // we know email so far
      return $this->output->set_status_header(200)->set_output(json_encode(array('email' => $user['username'])))->set_content_type('application/json');
    }
    return $this->output->set_status_header(200)->set_output(json_encode($associated_site_user))->set_content_type('application/json');
  }
}
