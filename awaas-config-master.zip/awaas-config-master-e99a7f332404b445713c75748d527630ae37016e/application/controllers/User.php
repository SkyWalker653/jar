<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->library('session');    
    $this->load->library('form_validation');
    $this->load->library('site_library', NULL, 'site');
    $this->load->helper('layout');
    $this->load->helper('form');
    $this->load->helper('url');
    $this->load->library('auth');
    $this->load->model('users_model');
  }

  /**
   * Index Page for this controller.
   *
   * Maps to the following URL
   * 		http://example.com/index.php/welcome
   * 	- or -
   * 		http://example.com/index.php/welcome/index
   * 	- or -
   * Since this controller is set as the default controller in
   * config/routes.php, it's displayed at http://example.com/
   *
   * So any other public methods not prefixed with an underscore will
   * map to /index.php/welcome/<method_name>
   * @see https://codeigniter.com/user_guide/general/urls.html
   */
  public function index() {
    if ($this->auth->is_authenticated()) {
      return redirect('/dashboard');
    }
    $this->load->view('commons/header');
    $this->load->view('login');
    $this->load->view('commons/footer');
  }

  public function login() {
    if ($this->input->server('REQUEST_METHOD') != 'GET') {
      return redirect('/');
    } 
   

    // getting variables from configuration
    $redirect_url = $this->config->item('redirect');
    $oauth_authorize_url = $this->config->item('oauth_authorize_url');
    $client_id = $this->config->item('client_id');
    $scope = $this->config->item('scope');
    $secret = $this->config->item('secret');
    $token_url = $this->config->item('token_url');
    $tokens_url = $this->config->item('tokens_url');
    $profile_url = $this->config->item('profile_url');


    $p_state = $this->input->get('state');
    $p_code = $this->input->get('code');
    if(empty($p_state) || empty($p_code)){
      // seems to be a fresh get request
      $state = md5(uniqid(rand(), TRUE));
      $params = array(
        "response_type" => "code",
        "client_id" => $client_id,
        "redirect_uri" => $redirect_url,
        "scope" => $scope, //what you want to access
        "state" => $state // csrf token
      );
      $url = $oauth_authorize_url . '?' . http_build_query($params);
      // setting state in session
      $this->session->set_userdata('state', $state);
      // sending user to auth login page
      return $this->output->set_header("Location: " . $url);  
    }

    if($this->input->get('state') != $this->session->userdata('state')){
      // it's not freash request and redirected from auth but seems is not valid
      return $this->output->set_status_header('400', 'Request data did not match !!');
    }

    // request seems valid, tring to get further details
    $state = $this->session->userdata('state');
    $code = $this->input->get('code');
    $result = get_access_token($code, $token_url, $client_id, $secret, $scope, $redirect_url);
    $response = json_decode($result);

    if(!empty($response->error_description)) {
      // response seems to have issue seninding it to user
      return $this->output->set_status_header('400', $response->error_description);
    }
    
    $token_response = get_uuid($response->access_token, $tokens_url);
    $token_response_obj = json_decode($token_response);
    if(empty($token_response_obj->user_uuid)){
      return $this->output->set_status_header('400', 'no uuid associated!!');
    }
    
    $profile_url .= "/$token_response_obj->user_uuid";
      // getting profiles here
    $profile = get_profile_data($response->access_token,$profile_url );
    $profile = json_decode($profile);
    

    $user = $this->users_model->get_users(array('username' => $profile->mail), TRUE) ;     
    if(empty($user)){
        //register user
      $this->users_model->create_user(array('username'=>$profile->mail, 'role'=>'user'));        
      $user = $this->users_model->get_users(array('username' => $profile->mail), TRUE);  
    }

    $this->session->set_userdata(array('authenticated' => TRUE, 'id' => $user['id']));
    return redirect('/dashboard');
    
  }

  public function logout() {
    if ($this->input->server('REQUEST_METHOD') == 'GET') {
      $this->auth->logout_user();
      redirect('/');
    }
  }

  public function dashboard() {
    if (!$this->auth->is_authenticated()) {
      redirect('/');
    }
    if ($this->input->server('REQUEST_METHOD') == 'GET') {
      if ($this->input->is_ajax_request()) {
        return $this->output->set_status_header(200)->set_output(json_encode($this->site->get_users_sites()))->set_content_type('application/json');
      }
      return render_page('user-dashboard');
    }
    show_404();
  }

  public function register() {
    if ($this->auth->is_authenticated()) {
      redirect('/');
    }
    if ($this->input->server('REQUEST_METHOD') == 'GET') {
      render_page('user-registration');
    } else if ($this->input->is_ajax_request()) {
      $this->output->set_status_header(200)->set_output(json_encode(array("redirect" => '/login')))->set_content_type('application/json');
    } else {
      show_404();
    }
  }

  public function forgot_password() {
    $fields['user_name'] = $this->input->post('username', true);
    $fields['password'] = $this->input->post('password', true);
    render_page('forgot-password');
  }

  public function change_password() {
    if (!$this->auth->is_authenticated()) {
      return show_404();
    }
    if ($this->input->server('REQUEST_METHOD') == 'GET') {
      render_page('user-change-password');
    } else if ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->is_ajax_request()) {
      if (!$this->form_validation->run('change_password')) {
        return $this->output->set_status_header(400, 'Invalid data')->set_output(json_encode($this->form_validation->error_array()))->set_content_type('application/json');
      }
      $current_password = $this->input->post('current_password');
      $new_password = $this->input->post('new_password');

      if (!$this->auth->is_valid_current_password($current_password)) {
        return $this->output->set_status_header(400, 'Invalid data')->set_output(json_encode(array('current_password' => 'Invalid Current Password')))->set_content_type('application/json');
      }

      $this->auth->change_password($new_password);
      $this->output->set_status_header(200)->set_output(json_encode(array("redirect" => '/logout')))->set_content_type('application/json');
    } else {
      show_404();
    }
  }

  public function edit_profile(){
    if (!$this->auth->is_authenticated()) {
      return show_404();
    }
    if ($this->input->server('REQUEST_METHOD') == 'GET') {
      return render_page('edit-profile');
    }
    if ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->is_ajax_request()) {
      if ($this->form_validation->validate_user_details() == FALSE) {
        return $this->output->set_status_header(400, 'Invalid data')->set_output(json_encode($this->form_validation->error_array()))->set_content_type('application/json');
      }
      $data = $this->site->get_technical_details();
      
      $user = $this->auth->loggedin_user();    
      $associated_site_user = $this->sites_model->get_site_users(array('id'=>$user['associated_site_user']), TRUE);  
      if(!empty($associated_site_user)){
        $this->sites_model->update_site_user(array('id' => $associated_site_user['id']), $data);
        return $this->output->set_status_header(200)->set_output(json_encode(array("redirect" => '/user/dashboard')))->set_content_type('application/json');   
      } 
      // creating site user
      $site_user = $this->sites_model->create_site_user($data);
      // updating mapping
      $this->users_model->update_user( array('associated_site_user'=>$site_user['id']), array('id' => $user['id']));
      return $this->output->set_status_header(200)->set_output(json_encode(array("redirect" => '/user/dashboard')))->set_content_type('application/json');        
      
    }

  }

}
