<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Organization extends CI_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->library('session');
    $this->load->library('form_validation');
    $this->load->helper('url');
    $this->load->model('organizations_model');
    $this->load->library('auth');
  }

  public function hierarchy($organization) {    
    if (!$this->auth->is_authenticated()) {
      return show_404();
    }
    if ($this->input->server('REQUEST_METHOD') == 'GET'  && $this->input->is_ajax_request()) {    
      $this->output->set_status_header(200)->set_output(json_encode($this->organizations_model->get_hierarchy(array('id'=>$organization))))->set_content_type('application/json');
    } else {
      show_404();
    }
  }
}
