<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {

  public function __construct() {
    parent::__construct();
    $this->load->library('session');
    $this->load->helper('layout');
    $this->load->helper('url');
    $this->load->library('form_validation');
    $this->load->library('auth');
    $this->load->library('workflow');
    $this->load->library('site_library',NULL, 'site');
	
	$this->load->helper('security');
	$this->load->library('validation');
  }

  public function register() {
    if(!$this->auth->is_authenticated()){
      redirect('/');
    }
    
    if ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->is_ajax_request()) {   
	
	
		 
		if ($this->form_validation->validate_website_registration_form() == FALSE) {
			return $this->output->set_status_header(400, 'Invalid data')->set_output(json_encode($this->form_validation->error_array()))->set_content_type('application/json');
		} 
		  
	  
	  
      if ($this->input->post('step') == 3) {
        $resp = $this->site->register_site();
        if($resp['isSuccess'] ==! TRUE) {
          return $this->output->set_status_header(400, 'Invalid data')->set_output(json_encode($resp))->set_content_type('application/json');
        }
//      Its success redirect user to home 
        return $this->output->set_status_header(200)->set_output(json_encode(array("redirect" => '/user/dashboard')))->set_content_type('application/json');
      } 
      // ask user for next step
       return  $this->output->set_status_header(200)->set_output(json_encode(array()))->set_content_type('application/json');
    }
    
    return render_page('website-registration');
    
  }
  
  public function move_work_flow(){
    if ($this->input->server('REQUEST_METHOD') == 'GET' || ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->is_ajax_request())){
//     validation first
      $site_id = $this->input->post_get('site_id');
      $current_stage = $this->input->post_get('current_stage');
      $requested_stage = $this->input->post_get('requested_stage');
      $this->form_validation->set_data(array(
        'site_id' => $site_id,
        'current_stage'=> $current_stage,
        'requested_stage' => $requested_stage
      ));
      
      if(!$this->form_validation->run('move_workflow')){
        return $this->output->set_status_header(400, 'Invalid data')->set_output(json_encode($this->form_validation->error_array()))->set_content_type('application/json');        
      }
      
      
      if(($this->auth->is_owner_of_site($site_id) || $this->auth->is_admin()) && $this->workflow->is_valid_next_stage($current_stage, $requested_stage)){
        $res = $this->workflow->move($site_id, $current_stage, $requested_stage);
        if(array_key_exists('error', $res)){
          return $this->output->set_status_header(400, 'Invalid data')->set_output(json_encode(array('error'=>$res['error'])))->set_content_type('application/json');        
        }
        return $this->output->set_header($res['header'])->set_status_header(200)->set_output($res['content'])->set_content_type($res['content_type']);        
//       put your work flow logic here 
      }else{
        return $this->output->set_status_header(400, 'Invalid data')->set_output(json_encode(array('error'=>'You are not allowed to do it')))->set_content_type('application/json');        
      }
      
    }else{
      show_404();
    }
  }

}
