<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$config = array(
  'user_registration' => array(
    array(
      'field' => 'site_url',
      'label' => 'URL',
      'rules' => 'required'
    ),
    array(
      'field' => 'user_email',
      'label' => 'Email',
      'rules' => 'required'
    ),
    array(
      'field' => 'user_password',
      'label' => 'User Password',
      'rules' => 'required|min_length[5]|max_length[12]'
    ),
    array(
      'field' => 'min_dept_apex',
      'label' => 'Min Or Apex',
      'rules' => 'required|in_list[min,apex,dept]'
    ),
    array(
      'field' => 'min',
      'label' => 'Ministry',
      'rules' => 'required|greater_than[-1]'
    )
  ),
  'change_password' => array(
    array(
      'field' => 'current_password',
      'label' => 'Current Password',
      'rules' => 'required'
    ),
    array(
      'field' => 'new_password',
      'label' => 'New Password',
      'rules' => 'required|min_length[5]|max_length[12]'
    ),
    array(
      'field' => 'cnf_new_password',
      'label' => 'New Password Confirmed',
      'rules' => 'required|matches[new_password]'
    )
  ),
  'move_workflow' => array(
    array(
      'field' => 'current_stage',
      'label' => 'Current Stage',
      'rules' => 'required'
    ),
    array(
      'field' => 'requested_stage',
      'label' => 'Requested Stage',
      'rules' => 'required'
    ),
    array(
      'field' => 'site_id',
      'label' => 'Site ID',
      'rules' => 'required'
    )
  ),
  'login' => array(
    array(
      'field' => 'username',
      'label' => 'Username',
      'rules' => 'required'
    ),
    array(
      'field' => 'password',
      'label' => 'Password',
      'rules' => 'required'
    )
  ),
  'max_registration_steps' => array(
    array(
      'field' => 'step',
      'label' => 'Step',
      'rules' => 'required|less_than[4]'
    )
  ),
  'website_registration' => array(
    '0' => array(
      array(
        'field' => 'template',
        'label' => 'Template',
        'rules' => 'trim|required|greater_than[-1]|is_integer',
        'errors' => array(
          'required' => 'You must choose a Template',
          'greater_than' => 'You must choose a Template'
        )
      ),
    ),
    '1' => array(
      array(
        'field' => 'site_name',
        'label' => 'Name',
		'rules' => 'trim|required|is_safe_text|max_length[150]|strip_tags|xss_clean|is_valid_text',
		'errors' => array(
       
        )
      ),
      array(
        'field' => 'site_dc',
        'label' => 'Data Centre',
        'rules' => 'trim|required|greater_than[-1]|is_integer',
        'errors' => array(
          'required' => 'Please Select a Datacentre to host your site',
          'greater_than' => 'Please Select a Datacentre to host your site'
        )
      ),
      array(
        'field' => 'site_domain',
        'label' => 'Domain',
        'rules' => 'trim|required|is_url'
      )
    ),
    '2' => array(
      array(
        'field' => 'te_name',
        'label' => 'Name',
        'rules' => 'trim|required|max_length[50]|is_valid_name'
      ),
      array(
        'field' => 'te_org',
        'label' => 'Organization',
        'rules' => 'trim|required|greater_than[-1]|is_integer',
		'errors' => array(
          'greater_than' => 'Please select an Organisation'
        )
      ),
      array(
        'field' => 'te_addr',
        'label' => 'Address',
        'rules' => 'trim|required|is_address|max_length[100]|strip_tags|xss_clean|is_valid_text'
      ),
      array(
        'field' => 'te_state',
        'label' => 'State',
        'rules' => 'trim|required|is_alpha_space|max_length[100]'
      ),
      array(
        'field' => 'te_pincode',
        'label' => 'Pincode',
        'rules' => 'trim|required|is_valid_pincode'
      ),
      array(
        'field' => 'te_email',
        'label' => 'Email',
        'rules' => 'trim|required|valid_email'
      ),
      array(
        'field' => 'te_telephone',
        'label' => 'Telephone',
        'rules' => 'trim|required|is_valid_phone'
      ),
      array(
        'field' => 'te_mobile',
        'label' => 'Mobile',
        'rules' => 'trim|required|is_valid_mobile'
      )
    ),
    '3' => array(
      array(
        'field' => 'owner_name',
        'label' => 'Name',
        'rules' => 'trim|required|max_length[50]|is_valid_name'
      ),
      array(
        'field' => 'owner_org',
        'label' => 'Organization',
        'rules' => 'trim|required|greater_than[-1]|is_integer',
		'errors' => array(
          'greater_than' => 'Please select Organisation'
        )
      ),
      array(
        'field' => 'owner_addr',
        'label' => 'Address',
        'rules' => 'trim|required|is_address|max_length[100]|strip_tags|xss_clean|is_valid_text'
      ),
      array(
        'field' => 'owner_state',
        'label' => 'State',
        'rules' => 'trim|required|is_alpha_space|max_length[100]'
      ),
      array(
        'field' => 'owner_pincode',
        'label' => 'Pincode',
        'rules' => 'trim|required|is_valid_pincode'
      ),
      array(
        'field' => 'owner_email',
        'label' => 'Email',
        'rules' => 'trim|required|valid_email'
      ),
      array(
        'field' => 'owner_telephone',
        'label' => 'Telephone',
        'rules' => 'trim|required|is_valid_phone'
      ),
      array(
        'field' => 'owner_mobile',
        'label' => 'Mobile',
        'rules' => 'trim|required|is_valid_mobile'
      )
    )
  )
);
