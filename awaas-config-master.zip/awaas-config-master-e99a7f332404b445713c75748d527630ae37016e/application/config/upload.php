<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$config['upload_path'] = APPPATH.'/auth_letters/scanned';
$config['allowed_types'] = 'pdf';
$config['encrypt_name'] = TRUE;
$config['file_ext_tolower'] = TRUE;

  