<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['subclass_prefix'] = 'AWAS_';
$config['index_page'] = "";
$config['base_url'] = 'http://awaas.gov.in/';

$config['upload_path'] = 'auth_letters/scanned';
$config['allowed_types'] = 'pdf';

$config['generated_auth_letters_path'] = 'auth_letters/generated';
$config['scanned_auth_letters_path'] = 'auth_letters/scanned';

//pdf generate config
$config['phantom_path']='/opt/phantomjs-1.9/';

// oauth configuration

$config['oauth_authorize_url'] = 'http://auth.awaas.gov.in/oauth2/authorize'; // oauth2 server URL; Don't Change
$config['token_url'] = 'http://auth.awaas.gov.in/oauth2/token'; //oauth2 Token URL; Don't Change
$config['tokens_url'] = 'http://auth.awaas.gov.in/oauth2/tokens'; //oauth2 Token UUID URL; Don't Change
$config['profile_url'] = 'http://auth.awaas.gov.in/oauth2/user'; //oauth2 Profile URL
$config['client_id'] = 'awaas-client'; // Client ID
$config['secret'] = 'awaas-client';  // Client Secret
$config['scope'] = 'user_profile'; // Scope for callback
$config['redirect'] = 'http://awaas.gov.in/user/login'; // Redirect URI
